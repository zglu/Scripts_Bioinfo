#Rscript /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/bin/cellchat.R /hwfssz1/ST_EUROPE/P21Z10200N0120/USER/fenglili/luzhigang/bioinfo_pipeline/Result/CRC_E6/03.Cluster/sample_CRC_E6_bin50_seurat.rds mouse

library(CellChat)
library(patchwork)
library(Seurat)
library(NMF)
library(ggalluvial)
library(future)


options(stringsAsFactors = FALSE)
options(future.globals.maxSize= 6291456000)

args <- commandArgs(trailingOnly = TRUE)

obj <- readRDS(args[1])

num_clusters <- length(unique(sort(obj@meta.data$seurat_clusters)))
data.input <- as.matrix(obj@assays$Spatial@counts)
#meta_data <- cbind(rownames(obj@meta.data), obj@meta.data[,'Type', drop=F])
obj@meta.data$seurat_clusters <- paste0('cluster', obj@meta.data$seurat_clusters)
meta_data <- cbind(rownames(obj@meta.data), obj@meta.data[,'seurat_clusters', drop=F])
meta_data <- as.matrix(meta_data)

#cellchat <- createCellChat(object = data.input, meta = meta_data, group.by = "Type")
cellchat <- createCellChat(object = data.input, meta = meta_data, group.by = "seurat_clusters")

if ( args[2] == 'mouse' ) {
    CellChatDB <- CellChatDB.mouse
} else if ( args[2] == 'human' ) {
    CellChatDB <- CellChatDB.human
}
#CellChatDB <- CellChatDB.mouse
#CellChatDB <- CellChatDB.human
CellChatDB.use <- CellChatDB
cellchat@DB <- CellChatDB.use

cellchat <- subsetData(cellchat)
future::plan("multiprocess", workers = 4)
cellchat <- identifyOverExpressedGenes(cellchat)
cellchat <- identifyOverExpressedInteractions(cellchat)
#cellchat <- projectData(cellchat, PPI.mouse)   ##optional

cellchat <- computeCommunProb(cellchat)
cellchat <- filterCommunication(cellchat, min.cells = 10)
cellchat <- computeCommunProbPathway(cellchat)
cellchat <- aggregateNet(cellchat)
groupSize <- as.numeric(table(cellchat@idents))

pdf('cellchat_network.pdf', width = 9, height = 9)
#par(mfrow = c(1,2))
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, weight.scale = T, label.edge= F, title.name = "Number of interactions")
#netVisual_circle(cellchat@net$weight, vertex.weight = groupSize, weight.scale = T, label.edge= F, title.name = "Interaction weights/strength")
dev.off()

png('cellchat_network.png', width = 600, height = 600)
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, weight.scale = T, label.edge= F, title.name = "Number of interactions")
dev.off()

mat <- cellchat@net$weight
pdf('cellchat_seperate.pdf', width = 20, height = ceiling(num_clusters/4)*5 )
par(mfrow = c(ceiling(num_clusters/4),4))
for (i in 1:nrow(mat)) {
    mat2 <- matrix(0, nrow = nrow(mat), ncol = ncol(mat), dimnames = dimnames(mat))
    mat2[i, ] <- mat[i, ]
    netVisual_circle(mat2, vertex.weight = groupSize, weight.scale = T, edge.weight.max = max(mat), title.name = rownames(mat)[i])
}
dev.off()
png('cellchat_seperate.png', width = 800, height = ceiling(num_clusters/4)*200 )
par(mfrow = c(ceiling(num_clusters/4),4))
for (i in 1:nrow(mat)) {
    mat2 <- matrix(0, nrow = nrow(mat), ncol = ncol(mat), dimnames = dimnames(mat))
    mat2[i, ] <- mat[i, ]
    netVisual_circle(mat2, vertex.weight = groupSize, weight.scale = T, edge.weight.max = max(mat), title.name = rownames(mat)[i])
}
dev.off()
