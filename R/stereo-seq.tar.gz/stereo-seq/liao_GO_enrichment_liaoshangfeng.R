.libPaths("/dellfsqd1/ST_OCEAN/ST_OCEAN/USRS/zhouli/software/conda_env/R4/lib/R/library")
library(clusterProfiler)
library(ggplot2)   # ymj
library(stringr)   # ymj
args <- commandArgs(T)
genes <- read.table(args[1], header = FALSE)
model <- args[2]
if(grepl("mouse",model)){
    library(org.Mm.eg.db)
    model <- "org.Mm.eg.db"
}else if(grepl("human",model)){
    library(org.Hs.eg.db)
    model <- "org.Hs.eg.db"
}else{
    print ("Please check species, only mouse or human is OK")
}

genes$V1 <- as.character(genes$V1)
full = bitr(genes$V1, fromType = "SYMBOL" ,toType = c("ENSEMBL","ENTREZID") , OrgDb = model)

go <- enrichGO(gene = full$ENTREZID , OrgDb = model, ont = "ALL", pAdjustMethod = "fdr", pvalueCutoff = 0.05, readable = TRUE)

write.table(go, paste0(args[1],'.GO.xls') , sep = '\t' , quote = FALSE , row.names = FALSE)

### dotplot ##$
pdf(paste0(args[1],'.GO.dotplot.pdf'), width = 9, height =9 )
p <- dotplot(go, showCategory = 20) ##ymj
p + scale_y_discrete(labels=function(go) str_wrap(go, width=60)) ## ymj
dev.off()
png(paste0(args[1],'.GO.dotplot.png'), width = 600, height = 600)
p <- dotplot(go, showCategory = 20) ##ymj
p + scale_y_discrete(labels=function(go) str_wrap(go, width=60)) ## ymj
dev.off()

### barplot ###
#pdf(paste0(args[1],'.GO.barplot.pdf'))
#barplot(go, showCategory = 20)
#dev.off()
#png(paste0(args[1],'.GO.barplot.png'), width = 600, height = 600)
#barplot(go, showCategory = 20)
#dev.off()

### emapplot ###
library(enrichplot)
go2 <- pairwise_termsim(go)
pdf(paste0(args[1],'.GO.emapplot.pdf'))
emapplot(go2,showCategory=30)
dev.off()
png(paste0(args[1],'.GO.emapplot.png'),, width = 600, height = 600)
emapplot(go2,showCategory=30)
dev.off()
