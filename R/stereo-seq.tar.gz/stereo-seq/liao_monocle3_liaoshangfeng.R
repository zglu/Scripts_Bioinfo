#[luzhigang1@cngb-login-0-8 04.Pseudotime]$ cat monocle3.sh
#source /ldfssz1/ST_OCEAN/USER/liaoshangfeng/software/anaconda3/bin/activate
#conda activate R411
#Rscript /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/bin/monocle3.zr.R -i /hwfssz1/ST_EUROPE/P21Z10200N0120/USER/fenglili/luzhigang/bioinfo_pipeline/Result/CRC_E6/03.Cluster/sample_CRC_E6_bin50_seurat.rds -s CRC_E6 -o /hwfssz1/ST_EUROPE/P21Z10200N0120/USER/fenglili/luzhigang/bioinfo_pipeline/Result/CRC_E6/04.Pseudotime

library(monocle3)
library(ggplot2)
library(dplyr)
library(Seurat)

parser = argparse::ArgumentParser(description = 'Script for converting Stereo-seq matrix to seurat format')
parser$add_argument('-i', '--input', dest = 'input', help = 'input tsv filename')
parser$add_argument('-s', '--samples', dest = 'sample', help = 'sample ID, will be used as output prefix and seurat object ident')

parser$add_argument('-o', '--out', dest = 'outdir', help = 'directory where to save the output files, all output files will be indexed by sample ID')

parser$add_argument('--minCount', dest = 'minCount', default = 0, type = 'integer', help = 'minimum UMI number')
parser$add_argument('--maxCount', dest = 'maxCount', type = 'integer', help = 'maximum UMI number')
parser$add_argument('--minFeature', dest = 'minFeature', default = 0, type = 'integer', help = 'minimum Feature number')
parser$add_argument('--maxFeature', dest = 'maxFeature', type = 'integer', help = 'maximum Feature number')
parser$add_argument('--vg', dest = 'vg', default = 3000, type = 'integer', help = 'number of variable genes, default 3000')
parser$add_argument('--pc', dest = 'pc', default = 30, type = 'integer', help = 'number of PC to use, default 30')
parser$add_argument('--resolution', dest = 'resolution', default = 0.8, help = 'cluster resolution, default 0.8')
parser$add_argument('--topn', dest = 'topn', help = 'save the top N markers')

parser$add_argument('--pointSize', dest = 'pointSize', default = 0.2, help = 'point size of spatial plot, default 0.2')
parser$add_argument('--colors', dest = 'colors', default = 70, type = 'integer', help = 'colors palette, one of c(25, 70), default 70')
opts = parser$parse_args()

obj <- readRDS(opts$input)

if (!is.null(opts$samples)){
#    samples <- as.vector(strsplit(opts$samples, ','))
    samples <- as.vector(opts$samples)
    samples <- paste0('sample_', samples)
    obj <- subset(obj, subset = orig.ident %in% samples)
}

data <- obj@assays$Spatial@counts

cds <- new_cell_data_set(as(data, 'sparseMatrix'),
                         cell_metadata = obj@meta.data,
                         gene_metadata = data.frame(gene_short_name = row.names(data),
                                                    row.names = row.names(data)
                                                    )
                         )

cds <- preprocess_cds(cds, num_dim = 30)

if (!is.null(opts$samples)){
    cds <- align_cds(cds, alignment_group = 'orig.ident')
}

cds <- reduce_dimension(cds)
cds <- cluster_cells(cds)
cds <- learn_graph(cds)

#cluster color
cluster_Palette <- c('dodgerblue2', '#E31A1C', 'green4', '#6A3D9A', '#FF7F00', 'black', 'gold1',
                     'skyblue2', '#FB9A99', 'palegreen2', '#CAB2D6', '#FDBF6F', 'gray70', 'khaki2',
                     'maroon', 'orchid1', 'deeppink1', 'blue1', 'steelblue4', 'darkturquoise',
                     'green1', 'yellow4', 'yellow3','darkorange4', 'brow')

p1 <- plot_cells(cds, color_cells_by = 'seurat_clusters',
#p1 <- plot_cells(cds, color_cells_by = 'cluster_Palette',
                 label_groups_by_cluster = FALSE,
                 label_leaves = FALSE,
                 label_branch_points = FALSE,
                 label_cell_groups = FALSE,	#added by ghb to draw a legend in fig1
                 graph_label_size = 1.5,
                 cell_stroke = 0.8)
ggsave(plot = p1, file = 'learn_graph.seurat_clusters.png')

get_earliest_principal_node <- function(cds, time_bin = '0'){

    cell_ids <- which(colData(cds)[, 'seurat_clusters'] == time_bin)

    closest_vertex <- cds@principal_graph_aux[['UMAP']]$pr_graph_cell_proj_closest_vertex
    closest_vertex <- as.matrix(closest_vertex[colnames(cds), ])
    root_pr_nodes <- igraph::V(principal_graph(cds)[['UMAP']])$name[as.numeric(names(which.max(table(closest_vertex[cell_ids,]))))]
    root_pr_nodes

}

#cds <- order_cells(cds, root_pr_nodes = get_earliest_principal_node(cds, time_bin = opts$root))
#cds <- order_cells(cds, root_pr_nodes = get_earliest_principal_node(cds, time_bin = '0'))
cds <- order_cells(cds, root_pr_nodes = get_earliest_principal_node(cds))	#changed by ghb to select a root automatically

p2 <- plot_cells(cds, color_cells_by = 'pseudotime',
                 label_cell_groups = FALSE,
                 label_leaves = TRUE,
#label_branch_points = TRUE,
                 label_branch_points = FALSE,
                 graph_label_size = 3,		#change 1.5 to 3 by ghb to get a clear number dot
                 cell_stroke = 0.8)

ggsave(plot = p2, file = 'learn_graph.pseudotime.png')

#added by ghb to draw a marker gene expression pseudotime pic

marker_test_res = top_markers(cds, group_cells_by="seurat_clusters", reference_cells=1000, cores=8)
top_specific_markers = marker_test_res %>% top_n(5)
top_specific_marker_ids = unique(top_specific_markers %>% pull(gene_id))
target_ids = top_specific_marker_ids[1:5]
target_cds = cds[rowData(cds)$gene_short_name %in% target_ids]
p3 <- plot_genes_in_pseudotime(target_cds)
ggsave(plot = p3, file = 'marker_gene_pseudotime.png')
