#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use Cwd;

my ($platform,$list,$bin,$pinfo,$qsub,$ln,$qc,$Greads);
my ($Outdir) = (".");
GetOptions(
	"platform:s"	=>	\$platform,
	"list:s"	=>	\$list,
	"pinfo:s"	=>	\$pinfo,
        "bin:s"		=>	\$bin,
        "outdir:s"	=>	\$Outdir,
	"qsub:s"	=>	\$qsub,
	"ln"		=>	\$ln,
	"qc"		=>	\$qc,
	"Greads"	=>	\$Greads  # reads number(G) required
);

die &usage unless(defined $list && defined $pinfo && defined $bin);
$platform ||= "NA" ;
my $pwd = getcwd;

$Outdir = ($Outdir eq "." || $Outdir eq "./") ? $pwd : ($Outdir =~ /^\//) ? $Outdir : $pwd."/".$Outdir;
system("mkdir -p -m 755 $Outdir") unless (-d $Outdir);

$pinfo = ($pinfo =~ /^\//) ? $pinfo : $pwd."/".$pinfo;

#my @samples=split/,|\s+/,$sample;
#$bin||=50;
#$model||="mouse";
#$qsub ||="vf=200G,p=1 -P P18H19700N0376 -q st.q";

my $sample_name;
my ($Tissue,$SampleID,$ChipID,$SpeciesName,$RefGenome);
open LIST, "$list";
while (<LIST>)
{
	chomp;
	next if (/^#/);
	#my @array = split /\t/;
	my @array = split /\s+/;
	system("mkdir -p -m 755 $Outdir/$array[0]") unless (-d "$Outdir/$array[0]");
	my $outdir = "$Outdir/$array[0]";

	$sample_name .= "$array[0],";
	$SampleID .= "\t$array[0]";
	$ChipID .= "\t$array[1]";
	$SpeciesName .= "\t$array[2]";
	$Tissue .= "\t$array[3]";
	$RefGenome .= "\t$array[4]";

	if($array[2]=~/mouse/){
		print "\n\t\e[;35;3mNotice: You have choose model 'mouse' !!!\e[;37;3m\n\n";
	}
	if($array[2]=~/human/){
    	print "\n\t\e[;35;3mNotice: You have choose model 'human' !!!\e[;37;3m\n\n";
	}

	my $sample = $array[0];
	my $model = $array[2];
	system("mkdir $outdir/01.Filter") unless (-d "$outdir/01.Filter");
	system("mkdir $outdir/01.Filter/result") unless (-d "$outdir/01.Filter/result");
	if($platform eq 'SAP'){
		if(-e "$array[-1]/07.report/new_final_result.json"){
			`cp $array[-1]/07.report/new_final_result.json $outdir/01.Filter` ;
		}elsif(-e "$array[-1]/07.report/$array[1].statistics.json"){
			`cp $array[-1]/07.report/$array[1].statistics.json $outdir/01.Filter/new_final_result.json` ;
		}else{
			print "please check! no new_final_result.json or $array[1].statistics.json\n";
		}

	(-e "$array[-1]/06.saturation/plot_200x200_saturation.png") ? `cp $array[-1]/06.saturation/plot_200x200_saturation.png $outdir/01.Filter` : (print  "Can not find 'plot_200x200_saturation.png' in directory $array[-1], please check!\n");
	`cp $array[-1]/00.mapping/*barcodeMap.stat $outdir/01.Filter/result`;
	`cp $array[-1]/02.count/*summary.stat $outdir/01.Filter/result`;
	`cp $array[-1]/00.mapping/*final.out $outdir/01.Filter/result`; # 20220816
	}
	else{
	(-e "$array[-1]/new_final_result.json") ? `cp $array[-1]/new_final_result.json $outdir/01.Filter` : (print "Warning: Can not find 'new_final_result.json' in directory $array[-1], please check!\n");
	(-e "$array[-1]/plot_200x200_saturation.png") ? `cp $array[-1]/plot_200x200_saturation.png $outdir/01.Filter` : (print  "Can not find 'plot_200x200_saturation.png' in directory $array[-1], please check!\n");
	`cp $array[-1]/00.fq/*barcodeMap.stat $outdir/01.Filter/result`;
	`cp $array[-1]/02.alignment/*summary.stat $outdir/01.Filter/result`;
	`cp $array[-1]/02.alignment/*final.out $outdir/01.Filter/result`;  # 20220816
	}
	system ("mkdir -m 755 -p $outdir/02.GeneExpMatrix") unless (-d "$outdir/02.GeneExpMatrix");
	system ("mkdir -m 755 -p $outdir/03.Cluster") unless (-d "$outdir/03.Cluster");
	system ("mkdir -m 755 -p $outdir/04.Pseudotime") unless (-d "$outdir/04.Pseudotime");
	system ("mkdir -m 755 -p $outdir/05.Annotation") unless (-d "$outdir/05.Annotation");
	system ("mkdir -m 755 -p $outdir/06.Interaction") unless (-d "$outdir/06.Interaction");
	system ("mkdir -m 755 -p $outdir/07.GO_KEGG") unless (-d "$outdir/07.GO_KEGG");
	if($array[-2]=~/\.gz/){
	#	system("ln -sf $array[-2] $outdir/02.GeneExpMatrix/lasso.final.gem.gz");
		system("ln -sf $array[-2] $outdir/02.GeneExpMatrix/$array[1].tissue.gem.gz")
	}else{
		#system("ln -sf $array[-2] $outdir/02.GeneExpMatrix/lasso.final.gem");
		system("ln -sf $array[-2] $outdir/02.GeneExpMatrix/$array[1].tissue.gem");
	}
		##### link maxrix of whole spots ##############
	if($platform eq 'SAP'){
		(-e "$array[-1]/04.tissuecut/$array[1].gem.gz") ? system("ln -sf $array[-1]/04.tissuecut/$array[1].gem.gz $outdir/02.GeneExpMatrix/$array[1].gem.gz") : (print  "\tCan not find '$array[1].gem.g' in directory $array[-1], please check!\n");
	}
	else{
	(-e "$array[-1]/$array[1].gem.gz") ? system("ln -sf $array[-1]/$array[1].gem.gz $outdir/02.GeneExpMatrix/$array[1].gem.gz") : (print  "\tCan not find '$array[1].gem.g' in directory $array[-1], please check!\n");
	}
		####### link ssDNA image to analysis dir ################# liucj
=pod
	my $ssDNA = "";
	if(opendir (SSDNADIR, "/zfssz3/ST_BIGDATA/stereomics/ImageDatabase/$array[1]"))
	{
		while(my $name = readdir(SSDNADIR))
		{
			next if ($name =~ /\.json|\.tar.gz/); # SS200000128TR_E3_20211207.json SS200000128TR_E3_20211207.tar.gz
			if($name =~ /$array[1]/){
				$ssDNA = `ls /zfssz3/ST_BIGDATA/stereomics/ImageDatabase/$array[1]/$array[1]*/registration/1_origin/3.jpg`; # 默认路径
				chomp $ssDNA;
			}elsif($name =~ /registration/){
				$ssDNA = "/zfssz3/ST_BIGDATA/stereomics/ImageDatabase/$array[1]/registration/1_origin/3.jpg";
			}
		}
	}else{
		print "\t$array[1]: Error in opening ssDNA image dir: /zfssz3/ST_BIGDATA/stereomics/ImageDatabase/$array[1]\n";
	}
	(-e $ssDNA ) ? `cp $ssDNA  $outdir/$array[0].image.png ` :(print "\t$array[1]: No ssDNA image, get ssDNA manually and upload to: Result/$array[0]/$array[0].image.png.\n");
	$ssDNA = "";
=cut
		##########################################################

	open SH_BINSTAT,">$outdir/02.GeneExpMatrix/binstat.sh" or die $!;
	print SH_BINSTAT "/ldfssz1/ST_OCEAN/USER/liaoshangfeng/software/anaconda3/envs/py3/bin/python3 /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/bin/diffbin_stat.for_report.py $array[-2] $sample > $outdir/02.GeneExpMatrix/lasso.final.gem.binstat\n";

### 03.Cluster ###
	open SH_SEURAT,">$outdir/03.Cluster/seurat.sh" or die $!;
	print SH_SEURAT "source /ldfssz1/ST_OCEAN/USER/liaoshangfeng/software/anaconda3/bin/activate
conda activate R411
Rscript /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/bin/STOmics_seurat.zr.R -i $array[-2] -b $bin -s $sample -o $outdir/03.Cluster 2>seurat.log \n";
close SH_SEURAT;

### 04.Pseudotime ###
	open SH_PSEUDOTIME,">$outdir/04.Pseudotime/monocle3.sh" or die $!;
	print SH_PSEUDOTIME "source /ldfssz1/ST_OCEAN/USER/liaoshangfeng/software/anaconda3/bin/activate
conda activate R411
Rscript /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/bin/monocle3.zr.R -i $outdir/03.Cluster/sample_$sample\_bin$bin\_seurat.rds -s $sample -o $outdir/04.Pseudotime \n";
	close SH_PSEUDOTIME;

### 05.Annotation ###
	system("mkdir -m 755 -p $outdir/05.Annotation/SciBet") unless (-d "$outdir/05.Annotation/SciBet");
	system("mkdir -m 755 -p $outdir/05.Annotation/SingleR") unless (-d "$outdir/05.Annotation/SingleR");
	open  SH_SCIBET,">$outdir/05.Annotation/SciBet/SciBet.sh" or die $!;
	print SH_SCIBET "source /ldfssz1/ST_OCEAN/USER/liaoshangfeng/software/anaconda3/bin/activate
conda activate R411
Rscript /jdfssz1/ST_TSCBI/PROJECT_temp/PROJECT/P21Z10200N0134/Pipeline2/STOmics/bin/SciBet.zr.R $outdir/03.Cluster/sample_$sample\_bin$bin\_seurat.rds /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/database/cell_anno_db/sciBet/$model\_all.csv $outdir/05.Annotation/SciBet $sample\n";
	close SH_SCIBET;

	open  SH_SINGLER,">$outdir/05.Annotation/SingleR/SingleR.sh" or die $!;
	print SH_SINGLER "source /ldfssz1/ST_OCEAN/USER/liaoshangfeng/software/anaconda3/bin/activate
conda activate R411
Rscript /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/bin/SingleR.zr.R $outdir/03.Cluster/sample_$sample\_bin$bin\_seurat.rds /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/database/cell_anno_db/SingleR/$model\_all.rData $outdir/05.Annotation/SingleR  $sample\n";
	close SH_SINGLER;

### 06.Interaction ###
	open SH_CELLCHAT, ">$outdir/06.Interaction/cellchat.sh" or die $!;
	print SH_CELLCHAT "source /ldfssz1/ST_OCEAN/USER/liaoshangfeng/software/anaconda3/bin/activate
conda activate R411
Rscript /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/bin/cellchat.R $outdir/03.Cluster/sample_$sample\_bin$bin\_seurat.rds $model \n";
	close SH_CELLCHAT;

### 07.GO_KEGG ###
	open SH_GOKEGG,">$outdir/07.GO_KEGG/step00.prework_GOKEGG.sh" or die $!;
	print SH_GOKEGG "perl /jdfssz1/ST_TSCBI/PROJECT_temp/PROJECT/P21Z10200N0134/Pipeline2/STOmics/bin/pre_GOKEGG.pl $outdir/03.Cluster/sample_$sample\_bin$bin\_AllMarkers.xls $outdir/07.GO_KEGG $model\n";
	close SH_GOKEGG;

	open SH, ">$outdir/qsub.$array[0].sh";
	print SH "cd $outdir/02.GeneExpMatrix; sh binstat.sh
cd $outdir/03.Cluster; sh seurat.sh
cd $outdir/04.Pseudotime; sh monocle3.sh
cd $outdir/05.Annotation/SciBet; sh SciBet.sh
cd $outdir/05.Annotation/SingleR/; sh SingleR.sh
cd $outdir/06.Interaction/; sh cellchat.sh
cd $outdir/07.GO_KEGG/; sh step00.prework_GOKEGG.sh
cd $outdir/07.GO_KEGG/; sh step01.each_cluster_GO.sh\n";
close SH;

	print "Please sh $outdir/07.GO_KEGG/step01.each_cluster_KEGG.sh by yourself\n";

	if (defined $qsub)
	{
		`qsub -cwd -l $qsub $outdir/qsub.$array[0].sh`;
		print "Shells of $array[0] were submitted\n";
	}
}
close LIST;
open PINFO, ">$Outdir/Project_information.txt";
print PINFO "Sample ID$SampleID\nChip ID$ChipID\nSpecies Name$SpeciesName\nTissue$Tissue\nReference Genome$RefGenome\n";

chop($sample_name);
open REPORT, ">$Outdir/generate_report.sh";
#print REPORT "perl /jdfssz1/ST_TSCBI/PROJECT_temp/PROJECT/P21Z10200N0134/Pipeline2/HTML_arf/STOmics/STOmics_arf_report.CN_and_EN.pl -sample $sample_name -bin $bin -step 1234567 -pinfo $pinfo -indir $Outdir\n";
print REPORT "perl /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/STOmics/STOmics_arf_report.CN_and_EN_v1.pl -sample $sample_name -bin $bin -step 1234567 -pinfo $pinfo -indir $Outdir\n";
print "Please sh $Outdir/generate_report.sh by yourself after running all shells\n";


	############## link fq/bam, get QC ############### liucj
my %readNum; my %fq;

        ##### link fq/bam for data delivery  #####
if(defined $ln)
{
	print "\n======== ln fq/bam ========================\n";
	print "\tTry linking fq/bam to analysis dir for deliver……\n";
	my %readNum; my %fq;
	open LIST, "$list";
	while(<LIST>)
	{
		next if (/^#/);
		$_ =~ s/,$//g;
		chomp;
		#my @array = split /\t/;
		my @array = split /\s+/;
		my $outdir = "$Outdir/$array[0]";
		system ("mkdir -m 755 -p $outdir/00.Rawdata") unless (-d "$outdir/00.Rawdata");
		system ("mkdir -m 755 -p $outdir/01.Bam") unless (-d "$outdir/01.Bam");
			#### ln -s bam for deliver data ####
		my $BamDir = "$array[-1]/02.alignment";
		if($platform eq 'SAP'){
			$BamDir = "$array[-1]/02.count";
		}
		opendir (DIR, $BamDir) or die "Error in opening backup dir:\n\t$array[-1]\n";
		while(my $name = readdir(DIR))
		{
			if($name =~ /q10.dedup.target.bam$/)
			{
				#system("ln -s $array[-1]/02.alignment/$name $outdir/01.Bam/$array[0]_$array[1].bam");
				system("ln -s $BamDir/$name $outdir/01.Bam/$array[0]_$array[1].bam");
				last;	# end the while
			}
		}
		#(-e "$array[-1]/02.alignment/$array[1]*bam") ? `ln -s $array[-1]/02.alignment/$array[1]*bam $outdir/01.Bam/` : (warn "Can not find *Aligned.sortedByCoord.out.merge.q10.dedup.target.bam,\n\t\t please link the bam file manully when need delivery!\n");
=pod
		if(-e "$array[-1]/../../spatialRNAvisualization_v3.json"){
			open JSON, "$array[-1]/../../spatialRNAvisualization_v3.json";
			while(my $js=<JSON>){
				chomp $js;
				if($js=~/spatialRNAvisualization_v3.Data/){
					$js = (split /:/, $js)[-1];
					$js =~ s/"1",//g;
					$js =~ s/"2",//g;
					$js =~ s/\[//g;
					$js =~ s/\]//g;
					$js =~ s/\s+//g;
					my @jss = split /,/, $js;
					foreach my $fq_h5(@jss){$fq{$fq_h5} = 0;}#print "$fq_h5\n";}
					foreach my $fq_h5(keys %fq){system "ln -s $fq_h5 $outdir/00.Rawdata/";}
					my $num = keys %fq;
					$readNum{$array[0]} = $num;
					%fq = ();
					$num = 0;
				}
			}
			close JSON;
		}else{
			print  "\tWarning:\tspatialRNAvisualization_v3.json not in STOmics backup path, REMOVE \"-ln\"  then reRun and link fq/bam manually.\n";
		}
=cut
	}
	print "\n\t####### fq + h5/bin files number #########\n\tsampleName\tNumber(fq+h5/bin)\n";
	foreach my $sample (keys %readNum){ print "\t$sample\t$readNum{$sample}\n"; }
	print "\t##########################################\n\n";
}

       ###### create QC table for feishu  ######
if(defined $qc){
	print "======== Create QC files ==================\n";
	print "\tGenerating QC files for feishu……\n\n";

        open QC2, ">QC.Table4feishu.ST.record.xls" or die $!;
        print QC2 "Sample_Name\tSpecies\tChipID\tTotal_Reads\tTotal_Q20\tTotal_Q30\tValid_CID_Reads\tValid_CID_Ratio\tClean_Reads\tClean_Reads_Ratio\tDuplication_Ratio\tUnique_Mapping_Reads\tExonic_Reads\tIntronic_Reads\tIntergenic_Reads\tTranscriptome_Reads\tUnique_Reads\tMean reads(50)\tMedian reads(50)\tMean gene type(50)\tMedian gene type(50)\tMean MID(50)\tMedian MID(50)\tMean reads(100)\tMedian reads(100)\tMean gene type(100)\tMedian gene type(100)\tMean MID(100)\tMedian MID(100)\tMean reads(150)\tMedian reads(150)\tMean gene type(150)\tMedian gene type(150)\tMean MID(150)\tMedian MID(150)\tMean reads(200)\tMedian Median reads(200)\tMean gene type(200)\tMedian gene type(200)\tMean MID(200)\tMedian MID(200)\n";
	my @factor = ("total_reads","Q20_bases_in_CID","Q30_bases_in_CID","Raw_Reads","Clean_Reads","DUPLICATION_RATE","Mapped_Reads_Number","EXONIC","INTRONIC","INTERGENIC","TRANSCRIPTOME","UNIQUE_READS");
	my @bin_factor = ("Mean_reads_per_spot","Median_reads_per_spot","Mean_gene_type_per_spot","Median_gene_type_per_spot","Mean_MID_per_spot","Median_MID_per_spot");
	my (%sample,%bin,%merge,%fq_num,%chip,@sample);
	my $bin_size;

	open LIST, "$list";
	while(<LIST>)
	{
                next if (/^#/);
                chomp;
                #my @array = split /\t/;
                my @array = split /\s+/;
		push @sample, $array[0];
		$chip{$array[0]}{'chip'} = $array[1];
		$chip{$array[0]}{'species'} = $array[2];
		my $new_final_result_json = "$array[-1]/new_final_result.json";
                if($platform eq 'SAP'){
         #               $new_final_result_json = "$array[-1]/07.report/new_final_result.json";
                         $new_final_result_json = "$Outdir/$array[0]/01.Filter/new_final_result.json"; # read from Resut dir
                }

		if(-e $new_final_result_json ){
			open FILE, "$new_final_result_json";
			while (<FILE>)
			{
				chomp;
				$_ =~ s/"//g;
				$_ =~ s/^\s+//g;
				$_ =~ s/\,//g;
				foreach my $factor (@factor)
                		{
                        		if ($_ =~ /$factor/)
                        		{
                                		my @info = split /:\s+/;
                                		if ($info[1] =~ /\(/)
                                		{
                                        		my @temp = split /\(/, $info[1];
                                        		$temp[0] =~ s/G//g;
                                        		$temp[0] =~ s/M//g;
                                        		$temp[1] =~ s/%//g;
                                        		$temp[1] =~ s/\)$//g;
                                        		$merge{$array[0]}{$info[0]}{'data'} += $temp[0];
                                        		$merge{$array[0]}{$info[0]}{'per'} += $temp[1];
                                        		$sample{$array[0]}{$info[0]} = "$merge{$array[0]}{$info[0]}{'data'}($merge{$array[0]}{$info[0]}{'per'}%)";
                                        		$fq_num{$array[0]}{$info[0]}[0] ++;
                                		} else {
                                        		if ($info[1] =~/G$/)
                                        		{
                                         		       $info[1] =~ s/G$//g;
                                                		$info[1] = $info[1] * 1000;
                                        		} elsif ($info[1] =~/K$/)
                                        		{
                                                		$info[1] =~ s/K$//g;
                                                		$info[1] = $info[1] / 1000;
                                        		}
                                        		$info[1] =~ s/M$//g if ($info[1] =~/M$/);
                                        		$info[1] =~ s/\%$//g if ($info[1] =~/\%$/);
                                        		$sample{$array[0]}{$info[0]} += $info[1];
                                        		$fq_num{$array[0]}{$info[0]} ++;
                                		}
                        		}
                		}
				if ($_ =~ /binSize/)
                		{
                        		my @info = split /:\s+/;
                        		$bin_size = $info[1];
                		}

                		foreach my $bin_factor (@bin_factor)
                		{
                        		if ($_ =~ /$bin_factor/)
                        		{
                                	my @info = split /:\s+/;
                                	$bin{$array[0]}{$bin_size}{$bin_factor} = $info[1];
                        		}
                		}
			}
			close FILE;
		}else{
			print  "Warning: Can not find 'new_final_result.json', please check!\n remove -qc to create the analysis shells\n";
		}
	}
	close LIST;

	###############
	my %Mapped_Reads_Number;
	foreach my $sample (@sample)
	{
        	my ($print, $raw_per_print,$clean_per_print,$sample_name,$sample_name1,$sample_name2,$clean_read);
        	my $factor_num = 0;
        	foreach my $factor (@factor)
        	{
                	$factor_num ++;
                	my $raw_per;
                	if ($factor eq "Raw_Reads")
                	{
                        	$sample{$sample}{$factor} =~ s/M//g;
                        	$sample{$sample}{"total_reads"} =~ s/G//g;
                        	$sample{$sample}{"total_reads"} =~ s/M//g;
                        	$raw_per = sprintf "%0.2f",($sample{$sample}{$factor}*100)/($sample{$sample}{"total_reads"});
                	}

                	my $clean_per;
                	if ($factor eq "Clean_Reads")
                	{
                        	$sample{$sample}{$factor} =~ s/M//g;
                        	$sample{$sample}{"Raw_Reads"} =~ s/M//g;
                        	$clean_per = sprintf "%0.2f",$sample{$sample}{$factor}*100/$sample{$sample}{"Raw_Reads"};
                	}

	                if ($factor eq "Q20_bases_in_CID" || $factor eq "Q30_bases_in_CID")
        	        {
                	        $sample{$sample}{$factor} =~ s/\%//;
                        	$sample{$sample}{$factor} = sprintf "%0.2f",$sample{$sample}{$factor}/$fq_num{$sample}{$factor};
                	}

                	if ($factor_num >= 7 && $factor_num <= 12)
                	{
                        	$sample{$sample}{$factor} =~ s/M//g;
                        	$sample{$sample}{$factor} =~ s/%//g;
                        	my @data = split /\(/,$sample{$sample}{$factor};
                        	$data[-1] =~ s/\)//g;
				# my $per = sprintf "%0.2f", $data[0]*100/$Mapped_Reads_Number{$sample}{"Mapped_Reads_Number"};
                        	$sample{$sample}{$factor} = "$data[0]";
                	}

                	if ($factor eq "Raw_Reads")
                	{
                        	$print .= "\t$sample{$sample}{$factor}\t$raw_per";
                	} elsif ($factor eq "Clean_Reads")
                	{
                        	$print .= "\t$sample{$sample}{$factor}\t$clean_per";
                	} else {
                        	$print .= "\t$sample{$sample}{$factor}";
                	}
        	}
        	print QC2 "$sample\t$chip{$sample}{'species'}\t$chip{$sample}{'chip'}$print";

	        for (50,100,150,200)
	        {
        	        my $print;
                	foreach my $bin_factor (@bin_factor)
                	{
                        	$print .= "\t$bin{$sample}{$_}{$bin_factor}";
                	}
                	print QC2 "$print";
        	}
        	print QC2 "\n";
	}
}

	######## get QC for sending email #####
if(defined $qc){

	$Greads ||= 2;  # if not set reads required

	open QC1, ">QC.list.xls" or die $!;
	print QC1 "Sample Name\tSN\tQC\tReads(G)\tMID in Spots Under Tissue(%)\tBin200 Median MID(K)\n";
        open LIST, "$list";
        while(<LIST>)
        {
                next if (/^#/);
                chomp;
                #my @array = split /\t/;
                my @array = split /\s+/;
		my($readsG,$qc2,$qc3,$judge) = (0,"NA","NA","NO"); # readsG, reads output; Greads, reads required.
		#my $new_final_result_json = "$array[-1]/new_final_result.json";
		my $new_final_result_json = "$Outdir/$array[0]/01.Filter/new_final_result.json";
		#if($platform eq 'SAP'){
			#$new_final_result_json = "$array[-1]/07.report/new_final_result.json";

		#}
		# if(-e "$array[-1]/new_final_result.json")
                if(-e $new_final_result_json)
		{
                        #open FILE, "$array[-1]/new_final_result.json";
                        open FILE, $new_final_result_json;
                        while (my $line = <FILE>)
			{
				chomp $line;
				if($line =~ /\"total_reads\":\s+\"(\S+)\",/g){ # "total_reads": "1.68G|M",
					my $laneG = $1;
					if($laneG =~ /M/){
						$laneG =~ s/M//g;
						$laneG = sprintf "%.2f", $laneG/1000;
						$readsG += $laneG;
					}elsif($laneG =~ /G/){
						$laneG =~ s/G//g;
						$readsG += $laneG;
					}elsif($laneG =~ /[\d]+/ && $laneG !~ /G/ && $laneG !~ /M/){
						$laneG = sprintf "%.4f", $laneG/1e9;
						$readsG += $laneG;
					}else{
						 print "$array[-1]/new_final_result.jsonb:\n\tneed check $line\n";
					}
				}
				if($line =~ /\"Fraction_MID_in_spots_under_tissue\":\s+\"(\S+)%\",/g){
					$qc2 = $1;
				}
				if($line =~ /\"binSize\":\s+\"200\"/g){
					<FILE>; <FILE>; <FILE>; <FILE>; <FILE>; # skip first 5 line
					chomp($qc3 = <FILE>);
					$qc3 =~ s/\s+\"Median_MID_per_spot\":\s+//g;
					$qc3 =~ s/K//g;
					$qc3 =~ s/"//g;
				}
			}
			if($readsG >= $Greads && $qc2 >= 50 && $qc3 >= 5){$judge= "Pass";}
			print QC1 "$array[0]\t$array[1]\t$judge\t$readsG\t$qc2\t$qc3\n";
			($readsG,$qc2,$qc3,$judge) = (0,"NA","NA","NO");
			close FILE;
         	}else{
			print "Waring: $array[0]\t$array[1]: do not exsits file new_final_result.json";
		}
	}

}

	############################################################################

sub usage{
    print STDERR"\e[;33;3m
        ---------------   Version   --------------
        Author:   Rui Zhang
        Email:    zhangrui7\@genomics.cn
        Update:   2021.11()
		  2022.01(Yufen Huang , create shells by list)
		  2022.03(Chuanjun Liu, create QC table and link fq/bam for deliver)

        STOmics analysis after obtaining <lasso.final.gem>, containing:
        02.GeneExpMatrix 03.Cluster 04.Pseudotime 05.Annotation 06.Interaction 07.GO_KEGG

        \e[;33;3m
        -------------   Parameters    -------------
        -platform   which platform to carry out the anslysis. Set SAP .
        -list    ** sample information file
        -pinfo   ** project information file
        -bin     ** bin size
        -outdir     default `pwd`
        -qsub       shells will be submitted to linux SGE system if detect this parameter
	-ln	    link FQ and Bam to analysis dir for delivery
	-qc	    generate two QC files, one is for updata Feishu's collection and the other is for email
	-Greads	    if set -qc option, give reads numver required, default is 2 for 2 G reads.

        ---------------   Example   ----------------
        perl $0 -list Chip.list -pinfo Project.list -bin 100 -ln -qc -Greads 2 -qsub='vf=200G,p=1 -P P18H19700N0376 -q st.q'

        ---------------   Note   ----------------
        1. Format of list, separate by tab (no header):
        SampleID	ChipID	SpeciesName(human or mouse)	Tissue ReferenceGenome(GRCh38(h) or GRCm38(m))	Pathway_GemFile	Pathway_ChipAnalysis_backup
        2931_B1_20211203	SS200000149TL_A4	human	Liver	GRCh38	/jdfssz1/ST_TSCBI/PROJECT_temp/PROJECT/P21Z10200N0134/2022.01.26_3Sample_hyf/SS200000149TL_A4.bin1.Lasso.gem.gz	/jdfssz2/ST_BIGDATA/Stereomics/autoanalysis_backup/P20Z10200N0157/null/SS200000149TL_A4_web_2_backup/result/SS200000149TL_A4_web_2/
        2. -pinfo format:
        projectID = P21Z10200N0134
        reportName = 重大出生缺陷和发育异常突变体时空组学分析报告
		\n \e[;33;3m";
    return;
}
