#[luzhigang1@cngb-login-0-8 05.Annotation]$ cat SciBet/SciBet.sh
#source /ldfssz1/ST_OCEAN/USER/liaoshangfeng/software/anaconda3/bin/activate
#conda activate R411
#Rscript /jdfssz1/ST_TSCBI/PROJECT_temp/PROJECT/P21Z10200N0134/Pipeline2/STOmics/bin/SciBet.zr.R /hwfssz1/ST_EUROPE/P21Z10200N0120/USER/fenglili/luzhigang/bioinfo_pipeline/Result/CRC_E6/03.Cluster/sample_CRC_E6_bin50_seurat.rds /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/database/cell_anno_db/sciBet/mouse_all.csv /hwfssz1/ST_EUROPE/P21Z10200N0120/USER/fenglili/luzhigang/bioinfo_pipeline/Result/CRC_E6/05.Annotation/SciBet CRC_E6


#mouse_all.csv: cellxgene expr matrix

suppressMessages(library(ggplot2))
suppressMessages(library(tidyverse))
suppressMessages(library(scibet))
suppressMessages(library(viridis))
suppressMessages(library(ggsci))
library(Seurat)

#input test data
args=commandArgs(T)
data=readRDS(args[1])
preddata=t(as.matrix(data@assays$SCT@counts))
#input reference data
database=readr::read_csv(args[2])
#cell annoation
database <- pro.core(database)
prd <- LoadModel(database)
label<-prd(preddata)
data@meta.data$celltype<-label
outdir<-args[3]
setwd(outdir)
samplename<-args[4]
#cell metadata with cluster & type label
filename1=paste(samplename,"SciBet.metadata.csv",sep="_")
filepath1=paste(outdir,filename1,sep="/")
write.table(data@meta.data,filepath1,row.names=FALSE,col.names=TRUE,sep=",")
#Cell count per celltype
cellnumstat=data.frame(table(data@meta.data$celltype))
names(cellnumstat)=c("celltype","number")
filename2=paste(samplename,"SciBet.cellnumstat_type.csv",sep="_")
filepath2=paste(outdir,filename2,sep="/")
write.table(cellnumstat,filepath2,row.names=FALSE,col.names=TRUE,sep=",")
#UMAP with celltype label
filename4=paste(samplename,"SciBet.scaleUMAP.pdf",sep="_")
filepath4=paste(outdir,filename4,sep="/")
pdf(file = filepath4,width = 10,height = 10)
DimPlot(object = data,group.by="celltype",reduction="umap",pt.size=0.5,label=T)
dev.off()
png(paste(samplename,"SciBet.scaleUMAP.png",sep="_"), width = 700,height = 600)
DimPlot(object = data,group.by="celltype",reduction="umap",pt.size=0.5,label=T)
dev.off()

#cluster&gene  heatmap
preddata_df=as.data.frame(preddata)
preddata_df$label<-label
etest_gene <- SelectGene(preddata_df, k = 50)
filename3=paste(samplename,"SciBet.CellgeneHeatmap.pdf",sep="_")
filepath3=paste(outdir,filename3,sep="/")
pdf(file = filepath3,width = 15,height = 5)
Marker_heatmap(preddata_df, etest_gene)
dev.off()
png(paste(samplename,"SciBet.CellgeneHeatmap.png",sep="_"), width = 900,height = 400)
Marker_heatmap(preddata_df, etest_gene)
dev.off()
