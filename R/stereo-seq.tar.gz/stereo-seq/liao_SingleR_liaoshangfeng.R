#Rscript /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/bin/SingleR.zr.R /hwfssz1/ST_EUROPE/P21Z10200N0120/USER/fenglili/luzhigang/bioinfo_pipeline/Result/CRC_E6/03.Cluster/sample_CRC_E6_bin50_seurat.rds /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/STOmics/database/cell_anno_db/SingleR/mouse_all.rData /hwfssz1/ST_EUROPE/P21Z10200N0120/USER/fenglili/luzhigang/bioinfo_pipeline/Result/CRC_E6/05.Annotation/SingleR  CRC_E6

library(Seurat)
library(dplyr)
library(SingleR)
library(pheatmap)
library(ggplot2)
#input seurat object
args=commandArgs(T)
data=readRDS(args[1])
#nomaldata=GetAssayData(data@assays$integrated,slot = "scale.data")
nomaldata=GetAssayData(data@assays$SCT,slot = "scale.data")
clusters=data@meta.data$seurat_clusters
#input reference bulid-in singleR
load(args[2])
#cell type annotation
cellpred=SingleR(test = nomaldata,ref = refdata,labels = refdata$label.main,clusters = clusters,assay.type.test = "logcounts",assay.type.ref = "logcounts")
celltype=data.frame(ClusterID=rownames(cellpred),celltype=cellpred$labels,stringsAsFactors = F)
#outputpath
out=args[3]
samplename=args[4]
#cell metadata with cluster & type label
data@meta.data$celltype <- plyr::mapvalues(x = as.integer(as.character(data@meta.data$seurat_clusters)), from =celltype$ClusterID , to = celltype$celltype)
filename1=paste(samplename,"SingleR.metadata.csv",sep="_")
filepath1=paste(out,filename1,sep="/")
write.table(data@meta.data,filepath1,row.names=FALSE,col.names=TRUE,sep=",")
#Cell count per celltype
cellnumstat=data.frame(table(data@meta.data$celltype))
names(cellnumstat)=c("celltype","number")
filename2=paste(samplename,"SingleR.cellnumstat_type.csv",sep="_")
filepath2=paste(out,filename2,sep="/")
write.table(cellnumstat,filepath2,row.names=FALSE,col.names=TRUE,sep=",")
#cluster score heatmap
filename3=paste(samplename,"SingleR.CellClusterScoreHeatmap.pdf",sep="_")
filepath3=paste(out,filename3,sep="/")
pdf(file = filepath3,width = 10,height = 10)
#heatmap=plotScoreHeatmap(cellpred)
plotScoreHeatmap(cellpred,show_colnames=TRUE,angle_col="0")
dev.off()
png(paste(samplename,"SingleR.CellClusterScoreHeatmap.png",sep="_"),width = 600,height = 800)
plotScoreHeatmap(cellpred,show_colnames=TRUE,angle_col="0")
dev.off()

library(RColorBrewer)
qual_col_pals <- brewer.pal.info[brewer.pal.info$category == 'qual',]
cluster_Palette <- unique(unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals))))

#UMAP with celltype label
iPlot <- function(object, features, pt.size = 0.2){
    plot <- ggplot(object@meta.data, aes_string(x = 'x', y = 'y', color = features)) +
            geom_point(shape = 19, size = pt.size) + theme_void() +
            theme(axis.text = element_blank(), axis.ticks = element_blank(), panel.grid = element_blank(),
                  axis.title = element_blank(), axis.line = element_blank()
                  )
    if (features %in% c('nCount_Spatial', 'nFeature_Spatial')){
        plot <- plot + scale_color_gradientn(colours = heatmap_Palette(100))
				+ guides(colour = guide_legend(override.aes = list(size=3), nrow = 10))
    }else if(features %in% c('seurat_clusters', 'celltype')){
		plot <- plot + scale_color_manual(values = cluster_Palette) +
			guides(colour = guide_legend(override.aes = list(size=3), nrow = 10))
    }
#plot <- plot + theme_void() + theme(legend.position="right", legend.title=element_blank(), legend.key.size = unit(2, 'cm'))
            #plot <- plot + theme_void()
                    return(plot)
}

filename4=paste(samplename,"SingleR.scaleUMAP.pdf",sep="_")
filepath4=paste(out,filename4,sep="/")
plot3 <- DimPlot(object = data,group.by="celltype",reduction="umap",cols = cluster_Palette, pt.size=0.3,ncol=1, label=F, label.size=2) + theme(legend.position="none",plot.title=element_blank(),axis.title.x=element_text(size=8),axis.title.y=element_text(size=8),axis.text.x=element_text(vjust=1,size=8),axis.text.y=element_text(vjust=1,size=8), plot.margin=margin(t=1,b=1,r=1,l=1))
plot4 <- iPlot(data, feature = "celltype" , pt.size = 0.2)
pdf(file = filepath4,width = 9,height = 3)
plot3|plot4
dev.off()
png(paste(samplename,"SingleR.scaleUMAP.png",sep="_"),width = 900,height = 300)
plot3|plot4
dev.off()
