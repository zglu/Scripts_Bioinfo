#!/usr/bin/perl -w
use strict;
use Getopt::Long;
my ($indir,$outdir,$help);
my ($step,$bin,$sample,$pinfo);
GetOptions(
        "help|h:s"=>\$help,
        "indir:s"=>\$indir,
        "pinfo:s"=>\$pinfo,
        "outdir:s"=>\$outdir,
        "sample:s"=>\$sample,
        "bin:s"=>\$bin,
        "step:s"=>\$step,
        );
chomp ($outdir||=`pwd`);
chomp ($indir||=`pwd`);
$bin||=50;
$step||="1234567";
die &usage if (defined $help);
die &usage unless (defined $sample && defined $pinfo);

my $arf_dir="$outdir/HTML_report/arf";           system ("mkdir -m 755 -p $arf_dir") unless (-d "$arf_dir");
my $BGI_result="$outdir/HTML_report/BGI_result"; system ("mkdir -m 755 -p $BGI_result") unless (-d "$BGI_result");
my $resource="$outdir/HTML_report/resource";     system ("mkdir -m 755 -p $resource") unless (-d "$resource");

my $nfigure = 1;
my $ntable = 1;
my $nreference =1;
my ($arf_en,$arf_cn);
$arf_cn="format = arf1.0\nlanguage = CN\n\n";
$arf_en="format = arf1.0\nlanguage = EN\n\n";

### 技术简介 ###
$arf_cn.="\%result\n\@title\n技术简介\n\@paragraph\n本项目使用华大自主研发的时空组学技术（STOmics）\\reference{$nreference}，分析目标样本的组织切片的空间基因表达模式。
实验流程：
1. 样本处理及质检：对目标组织样本进行冷冻和OCT包埋，并进行切片及RNA质量评估；
2. 切片及贴片：对OCT包埋的样本进行切片，切片后再将切片贴到时空芯片表面；
3. 组织透化：将铺贴到芯片上的组织进行切片固定和渗透。时空芯片上布置有空间捕获探针，能与组织细胞释放的mRNA分子结合，从而在芯片上抓取目标样本组织细胞的mRNA分子，并合成cDNA；
4. 文库制备及测序：cDNA合成后构建测序文库并完成测序；
5. 数据分析：针对下机数据进行质控和分析，最终得到目标样本组织细胞在空间位置上表达的基因信息。
时空组学数据分析的全流程见图$nfigure。\n
\@figure\nnumber = $nfigure\ntitle = \"时空组学数据分析流程图\"\nfile = <url = resource/STOmics_analysis_pipeline_cn.png; label = \"时空组学数据分析流程图\">\nsize = <width = 600; height = 400>\ndesc = \" \"\n\n";
$arf_en.="\%result\n\@title\nTechnology Introduction\n\@paragraph\nThis project uses the STOmics technology (STOmics)\\reference{$nreference}, which was independently developed by BGI to analyze spatial gene expression patterns in tissue sections from target samples.
The experimental processes are as follows:
1. Sample processing and quality inspection: target tissue samples are frozen and OCT embedded. RNA quality evaluation is then conducted on those sections.
2. Sample slicing and mounting: the OCT embedded samples are sliced, and slices are mounted onto the surface of STOmics chips.
3. Tissue permeabilization: the tissue laid on the chip is sectioned for fixation and permeabilization. Spatially labelled probe on the surface of the STOmics chip can capture the released mRNA molecules. Then reverse-transcription is performed, and the resulting cDNA product is released.
4. Library preparation and sequencing: a STOmics library is constructed and sequenced.
5. Data analysis: quality control is performed for sequenced data, and a full set of bioinformatic analyses are conducted to obtain the spatial gene expression information in the target tissue samples. An overview of the entire process is shown in Figure $nfigure.\n
\@figure\nnumber = $nfigure\ntitle = \"Flow chart of STOmics data analysis\"\nfile = <url = resource/STOmics_analysis_pipeline_en.png; label = \"Flow chart of STOmics data analysis\">\nsize = <width = 600; height = 400>\ndesc = \" \"\n\n";
$nfigure++;
$nreference++;


### 项目信息 ###
if(-e "$indir/Project_information.txt"){
    system("cp $indir/Project_information.txt $BGI_result");
}else{
    die "Please check file <Project_information.txt>";
}
my @samples=split/,|\s+/,$sample;
my $sample_num=@samples;
my $tmp_format;
foreach my $jj(2..$sample_num+1){
    $tmp_format.="format = <field = $jj; type = string; align =centre; desc = \"Sample\">\n";
}
$arf_cn.="\%result\n\@title\n项目信息\n\@paragraph\n本项目的组织、芯片/切片、参考基因组等信息见表$ntable。
\@table\nnumber = $ntable\ntitle = \"项目信息表\"\nfile = <url = BGI_result/Project_information.txt>\nformat = <field = 1; type = string; align =centre; desc = \"Content\">\n${tmp_format}\n";
$arf_en.="\%result\n\@title\nProject Information\n\@paragraph\nInformations of Tissues, Chips, Sections and Reference Genome in this project are shown in Table$ntable.
\@table\nnumber = $ntable\ntitle = \"Project informations\"\nfile = <url = BGI_result/Project_information.txt>\nformat = <field = 1; type = string; align =centre; desc = \"Content\">\n${tmp_format}\n";
$ntable++;

### 切片图像 ###
$arf_cn.="\%result\n\@title\n切片图像\n\@paragraph\n在时空组转录组建库测序过程中，采用荧光成像技术对目标组织切片进行显微观察，通过荧光成像结果可以确认目标样本组织的外形轮廓、组织结构、完整情况等基础信息，为后续的数据分析提供保障。本项目中的组织切片图像结果如图$nfigure所示。\n";
$arf_en.="\%result\n\@title\nTissue Fluorescence Imaging\n\@paragraph\nIn this process, fluorescence imaging technology was used for microscopic observation of target tissue sections, and basic information such as contour, organizational structure, and integrity of target sample tissues could be obtained. This information provides an image reference for subsequent data analysis. The result of tissue section images in this project is shown in Figure $nfigure.\n";
$arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"切片组织荧光成像图\"\n";
$arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Fluorescence imaging of sample section\"\n";
foreach my $each(@samples){
    # system("mkdir $BGI_result/$each");
    system ("mkdir -m 755 -p $BGI_result/$each") unless (-d "$BGI_result/$each");
    if(-e "$indir/$each/$each.image.png"){
        system("cp $indir/$each/$each.image.png $BGI_result/$each/$each.image.png");
    }else{
        die "Please check the fluogram <$indir/$each/$each.image.png>\n";
    }
    $arf_cn.="file = <url = BGI_result/$each/$each.image.png ;label = \"$each\">\n";
    $arf_en.="file = <url = BGI_result/$each/$each.image.png ;label = \"$each\">\n";
}
$arf_cn.="size = <width = 600>\ndesc=\" \"\n\n";
$arf_en.="size = <width = 600>\ndesc=\" \"\n\n";
$nfigure++;

my $subtitle=1;
### 分析结果 ###
### 1. Filter ###
### QC ###
foreach my $each(@samples){
    # system ("mkdir -p $BGI_result/$each/01.Filter");
    system ("mkdir -m 755 -p $BGI_result/$each/01.Filter") unless (-d "$BGI_result/$each/01.Filter");
    if(-e "$indir/$each/01.Filter/new_final_result.json"){
        system ("perl /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/STOmics/bin/generate_filter_report_table.split.v3.pl $each $indir/$each/01.Filter/");
        system ("cp $indir/$each/01.Filter/plot_200x200_saturation.png $BGI_result/$each/01.Filter/plot_200x200_saturation.png");
        system ("cp $indir/$each/01.Filter/*.xls $BGI_result/$each/01.Filter/");
    }else{
        die "Please check if Filter of $each was totally completed !!! \n";
    }
}
system ("paste /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/STOmics/resource_demo/table1_header.txt $BGI_result/*/01.Filter/table1_qcfilter.xls > $BGI_result/all_samples.table1_qcfilter.xls");
$arf_cn.="\%result\n\@title\n数据分析\n\@paragraph\n测序数据下机后，使用STOmics Analysis Workflow（SAW）\\reference{$nreference}进行4.1数据质控、4.2基因组比对和4.3基因表达定量。
\@subtitle\nnumber = $subtitle\n下机数据质控\n\@paragraph\n测序数据下机后，会对read1和read2进行数据质控，具体过程如下：
首先，将read1 中的CID 序列与芯片上的barcode序列进行比对，并提取含有效CID 的read pairs；然后对含有有效CID 的read pairs，将read1 的CID 序列转换为reads 在切片上的空间位置信息，写入read2 的ID中；最后对read2 的Valid Reads 进行QC过滤得到Clean Reads。质控统计结果见表$ntable。
测序文库结构、质控标准等详细信息参见辅助文档。
\@table\nnumber = $ntable\ntitle = \"下机数据质控统计结果\"\nfile = <url = BGI_result/all_samples.table1_qcfilter.xls>\nformat = <field = 1; type = string; align =centre; desc = \"Content\">\n${tmp_format}footnote = \"Total Reads: 原始下机数据的总reads；\"\nfootnote = \"Valid CID Reads：能够与芯片上的CID匹配的有效reads；\"\nfootnote = \"Valid CID Ratio: Valid CID Reads / Total Reads；\"\nfootnote = \"Clean Reads：从Valid CID Reads中，质控过滤得到Clean Reads；\"\nfootnote = \"Clean Reads Ratio: Clean Reads / Total Reads；\"\nfootnote = \"Clean Reads Q20: Clean Reads中质量值（ Q=-10log(err rate)）大于20的碱基百分比；\"\nfootnote = \"Clean Reads Q30: Clean Reads中质量值（ Q=-10log(err rate)）大于30的碱基百分比。\"\n";
$arf_en.="\%result\n\@title\nBioinformatics Analyses\n\@paragraph\nSTOmics Analysis Workflow(SAW)\\reference{$nreference} was used to perform 4.1 Quality Control of Sequencing Data, 4.2 Genome Alignment and 4.3 Quantification of Gene Expression.
\@subtitle\nnumber = $subtitle\nQuality Control of Sequencing Data\n\@paragraph\nQuality control was processed on Read1 and Read2. The detailed processes are described as follows:
Firstly, CID sequences in Read1 was compared with barcode sequences on chip, and read pairs containing valid CIDs are extracted. For read pairs containing valid CIDs, the CID sequence was converted into the spatial position information on the slice and written into the read ID of Read2. Then valid reads in Read2 were filtered out as final Clean Reads. Statistical quality control results are shown in $ntable.
For details on the sequencing library structure and quality control standards, please refer to supplementary supporting documents.
\@table\nnumber = $ntable\ntitle = \"Quality control results of sequencing data\"\nfile = <url = BGI_result/all_samples.table1_qcfilter.xls>\nformat = <field = 1; type = string; align =centre; desc = \"Content\">\n${tmp_format}footnote = \"Total Reads: The number of total reads;\"\nfootnote = \"Valid CID Reads: The number of effective reads that can match with chip CID to location information;\"\nfootnote = \"Valid CID Ratio: Valid CID Reads / Total Reads;\"\nfootnote = \"Clean Reads: The number of reads filtered through quality control from Valid CID Reads;\"\nfootnote = \"Clean Ratio: Clean Reads / Valid CID Reads;\"\nfootnote = \"Clean Reads Q20: The percentage of bases in Clean Reads with a mass value (Q=-10log(err rate)) greater than 20;\"\nfootnote = \"Clean Reads Q30: The percentage of bases in Clean Reads with a mass value (Q=-10log(err rate)) greater than 30.\"\n";
$ntable++;
$subtitle++;
$nreference++;

###  Alignment ###
my $tmp_format22;
foreach my $jj(2..2*$sample_num+1){
    $tmp_format22.="format = <field = $jj; type = string; align =centre; desc = \"Sample\">\n";
}
system ("paste /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/STOmics/resource_demo/table2_header.txt $BGI_result/*/01.Filter/table2_alignment.xls > $BGI_result/all_samples.table2_alignment.xls");
$arf_cn.="\n\@subtitle\nnumber = $subtitle\n基因组比对\n\@paragraph\n将Clean Reads与参考基因组进行比对，统计比对到外显子区、内含子区、基因间区等区域的reads数。比对结果见表$ntable。
\@table\nnumber = $ntable\ntitle = \"Clean Reads与参考基因组的比对结果统计\"\nfile = <url = BGI_result/all_samples.table2_alignment.xls>\nformat = <field = 1; type = string; align =centre; desc = \"Content\">\n${tmp_format22}footnote = \"Unique Mapping Reads: 比对到基因组唯一位置的reads数；\"\nfootnote = \"Multiple Mapping Reads：比对到基因组多个位置的reads数；\"\nfootnote = \"Un-mapping Reads：未比对到基因组的reads数；\"\nfootnote = \"Unique Mapping Reads + Multiple Mapping Reads + Un-mapping Reads = Clean Reads。\"\n";
$arf_en.="\n\@subtitle\nnumber = $subtitle\nGenome Alignment\n\@paragraph\nClean Reads are mapped to the reference genome, and the number of reads mapped to exon regions, intron regions and inter-genetic regions was counted. The statistical results are shown in Table$ntable.
\@table\nnumber = $ntable\ntitle = \"Statistics of Clean Reads aligned to the reference genome\"\nfile = <url = BGI_result/all_samples.table2_alignment.xls>\nformat = <field = 1; type = string; align =centre; desc = \"Content\">\n${tmp_format22}footnote = \"Unique Mapping Reads: The number of reads aligned to a single position of reference genome;\"\nfootnote = \"Multiple Mapping Reads: The number of reads aligned to multiple positions of reference genome;\"\nfootnote = \"Un-mapping Reads: The number of reads not aligned to reference genome;\"\nfootnote =\"Unique Mapping Reads + Multiple Mapping Reads + Un-mapping Reads = Clean Reads.\"\n";
$ntable++;
$subtitle++;


### 02.GeneExpMatrix ###
foreach my $each(@samples){
    # system("mkdir -p $BGI_result/$each/02.GeneExpMatrix");
    system ("mkdir -m 755 -p $BGI_result/$each/02.GeneExpMatrix") unless (-d "$BGI_result/$each/02.GeneExpMatrix");
    system("cp $indir/$each/02.GeneExpMatrix/lasso.final.gem.binstat $BGI_result/$each/02.GeneExpMatrix");
}
system ("paste /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/STOmics/resource_demo/table3_header.txt $BGI_result/*/01.Filter/table3_expression.xls > $BGI_result/all_samples.table3_expression.xls");
system ("cat /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/STOmics/resource_demo/table4_header.txt $BGI_result/*/02.GeneExpMatrix/lasso.final.gem.binstat > $BGI_result/all_samples.table4_binstat.xls");
$arf_cn.="\n\@subtitle\nnumber = $subtitle\n基因表达定量\n\@paragraph\n将Unique Mapping Reads与基因位置对应，去除Duplicated Reads，并根据MID校正计算得到所有基因的表达量。统计结果见表$ntable。
\@table\nnumber = $ntable\ntitle = \"Unique Mapping Reads与参考基因组的比对结果统计\"\nfile = <url = BGI_result/all_samples.table3_expression.xls>\nformat = <field = 1; type = string; align =centre; desc = \"Content\">\n${tmp_format22}footnote = \"Unique Mapping Reads: 比对到基因组唯一位置的reads数\"\nfootnote = \"Intergenic Reads：比对到基因间区的reads数；\"\nfootnote = \"Annotation Succeed Reads：比对到基因区域的reads数；\"\nfootnote = \"Intergenic Reads + Annotation Succeed Reads = Unique Mapping Reads；\"\nfootnote = \"Exonic Reads：比对到外显子区的reads数；\"\nfootnote = \"Intronic Reads：比对到内含子区的reads数；\"\nfootnote = \"Exonic Reads + Intronic Reads = Annotation Succeed Reads；\"\nfootnote = \"Duplicated Reads: MID重复的reads数\"\nfootnote = \"Final Unique Reads：最终有效的reads数\"\nfootnote = \"Duplicated Reads + Final Unique Reads = Annotation Succeed Reads。\"\n";
$arf_en.="\n\@subtitle\nnumber = $subtitle\nQuantification of Gene Expression\n\@paragraph\n Locate Unique Mapping Reads to genes, remove duplicate MIDs, and calculate the expression levels of all genes according to MID correction. The statistical results are shown in Table$ntable.
\@table\nnumber = $ntable\ntitle = \"Statistics of Unique Mapping Reads aligned to the reference genome\"\nfile = <url = BGI_result/all_samples.table3_expression.xls>\nformat = <field = 1; type = string; align =centre; desc = \"Content\">\n${tmp_format22}footnote = \"Unique Mapping Reads: The number of reads aligned to a single position of reference genome;\"\nfootnote = \"Intergenic Reads: The number of reads aligned to inter-genetic regions;\"\nfootnote = \"Annotation Success Reads: The number of reads aligned to gene regions;\"\nfootnote =\"Intergenic Reads + Annotation Succeed Reads = Unique Mapping Reads;\"\nfootnote = \"Exonic Reads: The number of reads aligned to exon regions;\"\nfootnote = \"Intronic Reads: The number of reads aligned to intron regions;\"\nfootnote = \"Exonic Reads + Intronic Reads = Annotation Success Reads;\"\nfootnote = \"Duplicated Reads: The number of reads with duplicated MIDs;\"\nfootnote = \"Final Unique Reads: The number of final valid reads.\"\nfootnote = \"Duplicated Reads + Final Unique Reads = Annotation Success Reads.\"\n";
$ntable++;

$arf_cn.="\@paragraph\n在时空组学技术（STOmics）中，Bin是分析数据统计的基本单元。一个Bin表示一个固定大小的区域，区域内DNB表达量累加，区域间不重合，数字表示单边DNB 数量。时空芯片上每个DNB 在基因表达热图上表现为一个像素点，此时的分析单元为Bin1，即一个像素点只包含一个DNB的数据。将相邻N×N个DNB数据合并，在基因表达热图上以一个像素点的形式展示，此时分析单元为BinN。如Bin100表示一个分析单元包含100×100=10000个DNB区域的数据。Bin大小的选择会根据细胞大小、基因数量进行调整。不同Bin Size的基因捕获统计结果见表$ntable。取Bin200对测序饱和度进行统计，结果见图$nfigure。
\@table\nnumber = $ntable\ntitle = \"不同Bin Size的基因捕获量统计结果\"\nfile = <url = BGI_result/all_samples.table4_binstat.xls>\nformat = <field = 1; type = string; align =centre; desc = \"Chip\">\nformat = <field = 2; type = string; align =centre; desc = \"Bin Size\">\nformat = <field = 3; type = string; align =centre; desc = \"Mean Gene Types\">\nformat = <field = 4; type = string; align =centre; desc = \"Median Gene Types\">\nformat = <field = 5; type = string; align =centre; desc = \"Mean MIDs\">\nformat = <field = 6; type = string; align =centre; desc = \"Median MIDs\">\nfootnote = \"Bin Size：合并作为一个单元进行分析的DNB数量；\"\nfootnote = \"Mean Gene Types：所有Bin中捕获到基因类型的平均数；\"\nfootnote = \"Median Gene Types：所有Bin中捕获到基因类型的中位数；\"\nfootnote = \"Mean MIDs：所有Bin中表征基因表达量的MID平均数；\"\nfootnote = \"Median MIDs：所有Bin中表征基因表达量的MID中位数。\"\nview = -1 \n";
$arf_en.="\@paragraph\nIn STOmics, Bin is the basic unit for data statistics which represents a region with a fixed size. The expression quantity of DNBs within the region accumulates, and all regions do not coincide with each other. The BBin number represents a unilateral DNB number. Each DNB on the STOmics chip is a pixel point on the gene expression heatmap, and the analysis unit at this time is Bin1, which means one Bin contains data from only one DNB data. When adjacent N×N DNB data is combined and displayed as a single pixel on the gene expression heat map, the analysis unit now is BinN. For instance, Bin100 indicates an analysis unit that contains data of 100 x 100 = 10,000 DNBs. The selection of Bin size could can be adjusted according to cell size and gene number. Statistical results of gene captured with different Bin sizes are shown in Table $ntable. Bin150 was used to detect the sequencing saturation, and the results are shown in Figure $nfigure.
For MID-based correction calculation and sequencing saturation description, please refer to supplementary supporting documents.
\@table\nnumber = $ntable\ntitle = \" Statistical of genes captured in different Bin sizes\"\nfile = <url = BGI_result/all_samples.table4_binstat.xls>\nformat = <field = 1; type = string; align =centre; desc = \"Chip\">\nformat = <field = 2; type = string; align =centre; desc = \"Bin Size\">\nformat = <field = 3; type = string; align =centre; desc = \"Mean Gene Types\">\nformat = <field = 4; type = string; align =centre; desc = \"Median Gene Types\">\nformat = <field = 5; type = string; align =centre; desc = \"Mean MIDs\">\nformat = <field = 6; type = string; align =centre; desc = \"Median MIDs\">\nfootnote = \"Bin Size: Combine the number of DNB analyzed as a unit;\"\nfootnote = \"Mean Gene Types: Average number of genes captured in a Bin;\"\nfootnote = \"Median Gene Types: Median number of genes captured in a Bin;\"\nfootnote = \"Mean MIDs: Average MID values representing gene expression levels in a Bin;\"\nfootnote = \"Median MIDs: Median MID values representing gene expression levels in a Bin.\"\nview = -1\n";
$ntable++;
$arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"测序饱和度曲线（Bin200）\"\n";
$arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Sequencing saturation curve (Bin200)\"\n";
foreach my $each(@samples){
    $arf_cn.="file =  <url = BGI_result/$each/01.Filter/plot_200x200_saturation.png; label = \"$each\">\n";
    $arf_en.="file =  <url = BGI_result/$each/01.Filter/plot_200x200_saturation.png; label = \"$each\">\n";
}
$arf_cn.="size = <width = 600>\ndesc=\"左图，横坐标为每个Bin中平均reads数，纵坐标为序列饱和度；中图，横坐标为每个Bin中reads数，纵坐标为检测到的基因数；右图，横坐标为每个Bin中reads数，纵坐标为其中的Unique reads数。\"\n\n";
$arf_en.="size = <width = 600>\ndesc=\"Left, x-axis is the average number of reads per Bin, y-axis is the sequence saturation; Middle, x-axis is the number of reads in each Bin, y-axis is the number of genes detected; Right, x-axis is the number of reads in each Bin, y-axis is the number of unique reads detected.\"\n\n";
$nfigure++;


### 03.Cluster ###
if($step=~/3/){
    open DATA_CP,">$outdir/cluster_cp.sh";
    print DATA_CP "mkdir 03.Cluster\n";
    $arf_cn.="\n\@subtitle\nnumber = $subtitle\n细胞聚类分析\n\@paragraph\n获得每张芯片的基因表达矩阵后，使用Seurat4.0\\reference{$nreference}软件进行矩阵统计、细胞聚类、筛选Marker基因等分析。\n\@paragraph\n矩阵统计\n取bin$bin统计基因表达矩阵中nCount（MID，基因表达量）和nFeature（基因数），并在样品的空间位置中进行展示，结果见图$nfigure。\n";
    $arf_en.="\n\@subtitle\nnumber = $subtitle\nCell Clustering Analysis\n\@paragraph\nAfter obtaining the gene expression matrix of each section, Seurat\\reference{$nreference} was  used to conduct cell clustering, marker gene screening and other analysis on gene expression data.\n\@paragraph\nMatrix Statistics\nnCount (MID, gene expression quantity) and nFeature (gene number) in the gene expression matrix (Bin$bin) are counted and displayed in the location of sample sections, as shown in Figure $nfigure.\n";
    $subtitle++;
    $nreference++;
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"基因表达矩阵统计(Bin$bin)\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Statistics of Gene expression matrix(Bin$bin)\"\n";
    foreach my $each(@samples){
        print DATA_CP "cp $indir/$each/03.Cluster/*.rds $indir/$each/03.Cluster/*.loom 03.Cluster/$each \n";
        # system ("mkdir -p $BGI_result/$each/03.Cluster");
        system ("mkdir -m 755 -p $BGI_result/$each/03.Cluster") unless (-d "$BGI_result/$each/03.Cluster");
        system ("cp $indir/$each/03.Cluster/*.png $indir/$each/03.Cluster/*.pdf $indir/$each/03.Cluster/*.xls $BGI_result/$each/03.Cluster");
        $arf_cn.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_nstat.png; label = \"$each\">\n";
        $arf_en.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_nstat.png; label = \"$each\">\n";
    }
    close DATA_CP;
    $arf_cn.="size = <width = 768>\ndesc=\"上图，基因表达量统计及空间排布；下图，基因数目统计及空间排布。\"\n\n";
    $arf_en.="size = <width = 768>\ndesc=\"Above: gene expression statistics and spatial distribution; Below,:gene number statistics and spatial distribution.\"\n\n";
    $nfigure++;

    $arf_cn.="\n\@paragraph\n细胞聚类\n通过基因的表达矩阵，首先对矩阵数据使用PCA进行降维处理，之后使用UMAP算法进行细胞聚类，并将细胞类群的每个细胞在样品组织切片的空间位置中进行展示，结果见图$nfigure。\n";
    $arf_en.="\n\@paragraph\nCells clustering\nBased on the gene expression matrix, PCA was used for dimensionality reduction of matrix data, and then the UMAP algorithm was used for cell clustering. The spatial position of each cluster is displayed, and the results are shown in Figure $nfigure.\n";
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"细胞聚类结果(Bin$bin)\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Results of cells clustering (Bin$bin)\"\n";
    foreach my $each(@samples){
        $arf_cn.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_cluster.png; label = \"$each\">\n";
        $arf_en.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_cluster.png; label = \"$each\">\n";
    }
    $arf_cn.="size = <width = 768>\ndesc=\"左图，UMAP算法细胞聚类结果；右图，细胞类群在样品组织切片空间排布。\"\n\n";
    $arf_en.="size = <width = 768>\ndesc=\"Left, cell clustering results using UMAP algorithm; Right, cell groups arranged in the space of the sample tissue section.\"\n\n";
    $nfigure++;

    $arf_cn.="\@paragraph\nMarker基因筛选\n通过Seurat软件分别计算每一类细胞与其他类群的差异表达基因，筛选Top10差异基因作为该类细胞的Marker基因。部分结果（只展示一个样本的Top3）见表$ntable。\n";
    $arf_en.="\@paragraph\nMarker Gene Screening\nThe Seurat package was used to calculate the differentially expressed genes of each cell type compared with the other groups, and the top 10 differentially expressed genes are screened as marker genes. Partial results (Only show top 3 markers of one sample) are shown in Table$ntable.\n";
    foreach my $each(@samples){
        $arf_cn.="\@table\nnumber = $ntable\ntitle = \"$each细胞类群Marker基因（Top3）\"\nfile = <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_top3_Markers.xls>\nformat = <field = 1; type = string; align =centre; align =centre; desc = \"P-value\">\nformat = <field = 2; type = string; align =centre; desc = \"Average log2FC\">\nformat = <field = 3; type = string; align =centre; desc = \"pct.1\">\nformat = <field = 4; type = string; align =centre; desc = \"pct.2\">\nformat = <field = 5; type = string; align =centre; desc = \"Adjusted P-value\">\nformat = <field = 6; type = string; align =centre; desc = \"Cluster\">\nformat = <field = 7; type = string; align =centre; desc = \"Gene\">\nfootnote = \"pct.1：在当前细胞类群（Cluster）中检测到的Marker细胞的百分比；\"\nfootnote = \" pct.2：在其余细胞类群（Cluster）中检测到的Marker细胞的百分比。\"\nview = -1\n\n";
        $arf_en.="\@table\nnumber = $ntable\ntitle = \"${each}Marker genes of cell clustering(Top3)\"\nfile = <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_top3_Markers.xls>\nformat = <field = 1; type = string; align =centre; align =centre; desc = \"P-value\">\nformat = <field = 2; type = string; align =centre; desc = \"Average log2FC\">\nformat = <field = 3; type = string; align =centre; desc = \"pct.1\">\nformat = <field = 4; type = string; align =centre; desc = \"pct.2\">\nformat = <field = 5; type = string; align =centre; desc = \"Adjusted P-value\">\nformat = <field = 6; type = string; align =centre; desc = \"Cluster\">\nformat = <field = 7; type = string; align =centre; desc = \"Gene\">\nfootnote = \"pct.1: Percentage of Marker cells in the current cell cluster;\"\nfootnote = \"pct.2: Percentage of Marker cells in other remaining cell clusters.\"\nview = -1\n\n";
        $ntable++;
        last;
    }
    my $tmp_fig1=$nfigure+1;
    my $tmp_fig2=$nfigure+2;
    $arf_cn.="\@paragraph\n对得到的Marker基因，统计其在不同细胞类群中的表达情况，使用聚类热图、气泡图和小提琴图等方式进行可视化展示，每个细胞类群中Top3基因的结果分别见图$nfigure、$tmp_fig1和$tmp_fig2。\n";
    $arf_en.="\@paragraph\nThe expression of Marker genes in different cell groups was counted and visualized by clustering heat maps, bubble maps and violin maps. The expression levels of Top3 genes in each cell cluster are shown seperately in Figure $nfigure, $tmp_fig1 and $tmp_fig2.\n";
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"Marker基因聚类热图（Bin$bin）\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Heatmap of Marker gene clustering (Bin$bin)\"\n";
    foreach my $each(@samples){
        $arf_cn.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_heatmapClusters.png; label = \"$each\">\n";
        $arf_en.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_heatmapClusters.png; label = \"$each\">\n";
    }
    $arf_cn.="size = <width = 768>\ndesc=\"横坐标为不同的细胞类群；纵坐标为Marker基因；黄色代表高表达，紫色代表低表达。\"\n\n";
    $arf_en.="size = <width = 768>\ndesc=\"The abscissa represents different cell groups; The ordinate is Marker gene; Yellow represents high expression and purple represents low expression.\"\n\n";
    $nfigure++;
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"Marker基因气泡热图（Bin$bin）\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Bubble heatmap of Marker gene (Bin$bin)\"\n";
    foreach my $each(@samples){
        $arf_cn.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_dotplotClusters.png; label = \"$each\">\n";
        $arf_en.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_dotplotClusters.png; label = \"$each\">\n";
    }
    $arf_cn.="size = <width = 768>\ndesc=\"横坐标为Marker基因，纵坐标为不同的细胞类群；颜色从浅到深，颜色越深表示基因平均表达量越高；圆形越大表示表达该基因的细胞数目越多。\"\n\n";
    $arf_en.="size = <width = 768>\ndesc=\"The abscissa is Marker gene and the ordinate is different cell group. The color ranges from light to dark, darker color represent higher expression level. Larger bubble indicates a higher percentage of cells expressing the gene in the cell group.\"\n\n";
    $nfigure++;
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"Marker基因小提琴图（Bin$bin）\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Violin diagram of Marker gene (Bin$bin)\"\n";
    foreach my $each(@samples){
        $arf_cn.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_vlnplotClusters.png; label = \"$each\">\n";
        $arf_en.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_vlnplotClusters.png; label = \"$each\">\n";
    }
    $arf_cn.="size = <width = 768>\ndesc=\"纵坐标为不同细胞类群，横坐标为Marker 基因表达量，数字越高表示基因的表达量越高。\"\n\n";
    $arf_en.="size = <width = 768>\ndesc=\"The ordinate is different cell groups, and the abscissa is specific marker genes’ expression levels. \"\n\n";
    $nfigure++;

    $arf_cn.="\@paragraph\n对Top1的Marker基因所属的细胞类群在样品组织上的空间排布进行可视化展示，结果见图$nfigure。\n";
    $arf_en.="\@paragraph\nThe top 1 marker gene of each cell groups is visualized in the cluster location of sample sections, and partial results are shown in Figure $nfigure.\n";
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"Marker基因的空间排布（Bin$bin）\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Spatial distribution of Marker genes (Bin$bin)\"\n";
    foreach my $each(@samples){
        $arf_cn.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_each_cluster.png; label = \"$each\">\n";
        $arf_en.="file =  <url = BGI_result/$each/03.Cluster/sample_$each\_bin$bin\_each_cluster.png; label = \"$each\">\n";
    }
    $arf_cn.="size = <width = 768>\ndesc=\"红色点表示切片中Marker基因所属的细胞类群在样品切片组织的位置，蓝色点表示其他细胞类群在样品切片组织的位置。\"\n\n";
    $arf_en.="size = <width = 768>\ndesc=\"The red dots represent the position of the cell group to which the marker gene belongs in the sample tissue section, and the blue dots represents the position of other cell groups in the sample tissue section.\"\n\n";
    $nfigure++;
}


### Pseudotime ###
if($step=~/4/){
    foreach my $each(@samples){
        # system("mkdir -p $BGI_result/$each/04.Pseudotime");
        system ("mkdir -m 755 -p $BGI_result/$each/04.Pseudotime") unless (-d "$BGI_result/$each/04.Pseudotime");
        system("cp $indir/$each/04.Pseudotime/*.png $BGI_result/$each/04.Pseudotime");
    }
    $arf_cn.="\n\@subtitle\nnumber = $subtitle\n拟时序分析\n\@paragraph\n拟时序分析（pseudotime analysis）也称为细胞轨迹分析（trajectory inference），是指根据不同细胞类群之间其基因差异表达的情况，获得细胞谱系的发育结果，构建细胞随着一个虚拟时间顺序的变化轨迹，以此重现细胞随时间变化而变化的过程。
        使用Monocle3\\reference{$nreference}软件进行拟时序分析，基于Seurat对象提取的矩阵进一步降维聚类，并判断降维后的聚类结果之间的表达量关联以确定是否属于同一发育轨迹。根据软件推测的发育轨迹进行细胞类群的可视化，结果见图$nfigure。\n";
    $arf_en.="\n\@subtitle\nnumber = $subtitle\nPseudotime Analysis\n\@paragraph\nPseudotime analysis, also known as trajectory inference, refers to obtaining cell lineage information according to the differentially expressed genes among different cell groups and constructing a change trajectory of cells in a virtual timeline. Based on these results, a cell change timeline can be recreated.
        Monocle3\\reference{$nreference} was used for Pseudo-time analysis. Based on the result of dimensionality reduction and clustering, we further estimated whether the clustering results belonged to the same developmental trajectory. The cell groups were visualized according to the developmental trajectories predicted by the software, and the results are shown in Figure $nfigure.\n";
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"细胞发育轨迹图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Cell development trajectory diagram\"\n";
    foreach my $each(@samples){
        $arf_cn.="file =  <url = BGI_result/$each/04.Pseudotime/learn_graph.seurat_clusters.png; label = \"$each\">\n";
        $arf_en.="file =  <url = BGI_result/$each/04.Pseudotime/learn_graph.seurat_clusters.png; label = \"$each\">\n";
    }
    $arf_cn.="size = <width = 768>\ndesc=\"图中黑色线条表示推测的细胞发育轨迹\"\n";
    $arf_en.="size = <width = 768>\ndesc=\"The black lines in the figure show the presumed trajectory of cell development.\"\n";
    $nfigure++;
    $nreference++;

    $arf_cn.="\@paragraph\n根据细胞发育轨迹结果中的节点信息，结合不同细胞类群中基因表达量的变化，Monocle3可以通过机器学习算法计算处于最早发育阶段的细胞，实现拟时序分析，结果见图$nfigure。\n";
    $arf_en.="\@paragraph\nAccording to the results of cell development trajectory, combined with the changes of gene expression levels in different cell groups, Monocle3 could identify the cells at the earliest developmental stage using a machine learning algorithm and create a pseudo-time analysis, as shown in Figure $nfigure.\n";
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"拟时序分析结果图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Diagram of pseudo time series analysis results\"\n";
    foreach my $each(@samples){
        $arf_cn.="file =  <url = BGI_result/$each/04.Pseudotime/learn_graph.pseudotime.png; label = \"$each\">\n";
        $arf_en.="file =  <url = BGI_result/$each/04.Pseudotime/learn_graph.pseudotime.png; label = \"$each\">\n";
    }
    $arf_cn.="size = <width = 768>\ndesc=\"图中黑色线条表示推测的细胞发育轨迹，颜色从紫色到黄色，颜色越接近黄色表示细胞发育时间越晚\"\n";
    $arf_en.="size = <width = 768>\ndesc=\"The black lines represent the presumed developmental trajectory of the cells, ranging in color from purple to yellow, and the color closer to yellow, the cells develop the later.\"\n";
    $nfigure++;

    $arf_cn.="\@paragraph\n在不同的细胞类群聚类结果中，选取Monocle3计算得到的Top5 Marker基因，按照已获得的拟时序结果进行基因表达量的拟时序作图，结果见图$nfigure。\n";
    $arf_en.="\@paragraph\nIn the clustering results of different cell classes, the top 5 marker genes calculated by Monocle3 were selected, and the gene expression levels were visualized according to the obtained pseudo-time results, as shown in Figure $nfigure.\n";
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"Marker基因动态表达结果图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Pseudo expression result of Marker gene\"\n";
    foreach my $each(@samples){
        $arf_cn.="file =  <url = BGI_result/$each/04.Pseudotime/marker_gene_pseudotime.png; label = \"$each\">\n";
        $arf_en.="file =  <url = BGI_result/$each/04.Pseudotime/marker_gene_pseudotime.png; label = \"$each\">\n";
    }
    $arf_cn.="size = <width = 768>\ndesc=\"横坐标表示拟时序结果；纵坐标表示基因表达量，颜色从紫色到黄色，颜色越接近黄色表示细胞发育时间越晚；黑色线条表示基因表达趋势。\"\n";
    $arf_en.="size = <width = 768>\ndesc=\"x-axis, the result of Pseudotime; y-axis, gene expression, and the color ranges from purple to yellow. the color closer to yellow, the cell development time is the later. The black line shows trends in gene expression.\"\n";
    $nfigure++;
}

### Annotation ###
my $tmp_nfig=$nfigure+1;
if($step=~/5/){
    foreach my $each(@samples){
#    system("mkdir -p $BGI_result/$each/05.Annotation/SciBet");
        # system("mkdir -p $BGI_result/$each/05.Annotation/SingleR");
        system ("mkdir -m 755 -p $BGI_result/$each/05.Annotation/SingleR") unless (-d "$BGI_result/$each/05.Annotation/SingleR");
        system("cp $indir/$each/05.Annotation/SingleR/*.png $indir/$each/05.Annotation/SingleR/*.pdf $BGI_result/$each/05.Annotation/SingleR");
#    system("cp $indir/$each/05.Annotation/SciBet/*.png $indir/$each/05.Annotation/SciBet/*.pdf $BGI_result/$each/05.Annotation/SciBet");
    }
    $arf_cn.="\n\@subtitle\nnumber = $subtitle\n细胞类群注释分析\n\@paragraph\n通过聚类分析得到不同细胞类群后，除了使用每个cluster的Marker基因信息对细胞类群进行初步的注释和分析之外，还可通过其他软件将细胞类群与参考数据库进行比较，以得到分群后不同细胞的细胞类群注释信息。\nSingleR细胞注释\nSingleR\\reference{$nreference}可以将细胞聚类结果中的每个cluster与参考数据库进行比较，根据该cluster与参考数据库中已知细胞类群基因表达谱的相似性对cluster进行打分，最终得到一个打分矩阵。通过打分矩阵结果即可将细胞聚类结果注释为不同的细胞类群。细胞类群的打分矩阵结果见图$nfigure，细胞类群注释结果见图$tmp_nfig。\n";
    $arf_en.="\n\@subtitle\nnumber = $subtitle\nAnnotation of Cell Clusters\n\@paragraph\nAfter dividing cells into different groups through cluster analysis, cell types are further identified by using marker gene information in public databases.\nSingleR Cell Annotation\nSingleR\\reference{$nreference}can recognize the existing cell clustering results based on Seurat, compare each cluster with a reference data set, and score the cluster according to the similarity of gene expression between cluster and known cell groups in the reference data set to obtain a scoring matrix. Cells/Bins can be annotated into different groups by scoring matrix results. The visualization results of the scoring matrix of cell clustering results are shown in Figure $nfigure, and the annotation results of cell groups are shown in Figure $tmp_nfig.\n";
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"SingleR细胞类群注释打分热图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Scoring heatmap of cell cluster annotation by SingleR\"\n";
    foreach my $each(@samples){
        $arf_cn.="file =  <url = BGI_result/$each/05.Annotation/SingleR/${each}_SingleR.CellClusterScoreHeatmap.png; label = \"${each}\">\n";
        $arf_en.="file =  <url = BGI_result/$each/05.Annotation/SingleR/${each}_SingleR.CellClusterScoreHeatmap.png; label = \"${each}\">\n";
    }
    $arf_cn.="size = <width = 768>\ndesc=\"横坐标为细胞聚类结果的cluster，纵坐标为参考数据集中包含的细胞类型，每一格颜色越接近黄色表示打分越高；最上方Labels表示SingleR给出的细胞注释结果\"\n";
    $arf_en.="size = <width = 768>\ndesc=\"x-axis, the cell clusters; y-axis, cell types contained in the reference dataset; the color ranges from blue to yellow, and the more closer to yellow, the higher scores; top lables represent the annotation result by SingleR.\"\n";
    $nfigure++;
    $nreference++;

    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"SingleR细胞类群注释结果图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Annotation results of cell clusters by SingleR\"\n";
    foreach my $each(@samples){
        $arf_cn.="file = <url = BGI_result/$each/05.Annotation/SingleR/${each}_SingleR.scaleUMAP.png; label = \"${each}\">\n";
        $arf_en.="file = <url = BGI_result/$each/05.Annotation/SingleR/${each}_SingleR.scaleUMAP.png; label = \"${each}\">\n";
    }
    $arf_cn.="size = <width = 768; height = 350>\ndesc=\"左图，UMAP细胞聚类结果图；右图，细胞类群在组织上的空间位置。每一种颜色代表SingleR注释得到的一种细胞类群。 \"\n";
    $arf_en.="size = <width = 768; height = 350>\ndesc=\"Left, cluster results of UMAP; Right, spatial locations of cell types on the tissue. Each color represents a cell cluster annotaed by SingleR.\"\n";
    $nfigure++;

#$tmp_nfig=$nfigure+1;
#$arf_cn.="\n\@paragraph\nSciBet细胞注释\nSciBet\\reference{$nreference}是一种基于有监督算法的细胞类群注释工具，软件中自带了基于参考数据库的模型训练结果，随后将输入的细胞聚类结果中的每个cluster进行分别建模，通过最大似然法对建模结果进行评估，同时筛选不同细胞类群中的差异基因。细胞类群注释结果见图$nfigure，细胞类群注释结果差异基因表达热图结果见图$tmp_nfig。\n";
#$arf_en.="\n\@paragraph\nSciBet Cell Annotation\nSciBet\\reference{$nreference} comes with model training results based on reference data sets. In operation, each cluster result is modeled separately and then evaluated based on a maximum likelihood method. In the training process, SciBet uses E-test in the software to screen for different genes in different cell groups. Because of the existing trained models within SciBet, SciBet performs analysis more quickly compared with other cell group annotation software. SciBet has also been widely used in single cell sequencing data analysis and spatiotemporal omics data analysis. The annotation results of cell groups are shown in Figure $nfigure, and the differential gene expression profile results of cell group annotation results are shown in Figure $tmp_nfig.\n"
#$nreference++;

#$arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"SciBet细胞类群注释结果图\"\n";
#$arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Annotation results of SciBet cell group\"\n";
#foreach my $each(@samples){
#    $arf_cn.="file =  <url = BGI_result/$each/05.Annotation/SciBet/${each}_SciBet.scaleUMAP.png; label = \"${each}\">\n";
#    $arf_en.="file =  <url = BGI_result/$each/05.Annotation/SciBet/${each}_SciBet.scaleUMAP.png; label = \"${each}\">\n";
#}
#$arf_cn.="size = <width = 768; height = 300>\ndesc=\"每一种颜色代表SciBet注释得到的一种细胞类群。 \"\n";
#$arf_en.="size = <width = 768; height = 300>\ndesc=\"Each color represents a cell class. \"\n";
#$nfigure++;

#$arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"SciBet细胞类群注释结果差异基因表达热图\"\n";
#$arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Heatmap of differential gene expression profiles of SciBet cell group annotation results\"\n";
#foreach my $each(@samples){
#    $arf_cn.="file =  <url = BGI_result/$each/05.Annotation/SciBet/${each}_SciBet.CellgeneHeatmap.png; label = \"${each}\">\n";
#    $arf_en.="file =  <url = BGI_result/$each/05.Annotation/SciBet/${each}_SciBet.CellgeneHeatmap.png; label = \"${each}\">\n";
#}
#$arf_cn.="size = <width = 2000>\ndesc=\"横坐标为细胞类群，纵坐标为Top差异基因；每个点代表该基因在当前细胞类群中的表达情况，颜色由蓝色到红色，表达差异更显著；点由小到大，表达差异更显著。\"\n";
#$arf_en.="size = <width = 2000>\ndesc=\"\x-axis, the cell clusters; y-axis, cell types contained in the reference dataset; the color ranges from blue to yellow, and the more closer to yellow, the higher scores; top lables represent the annotation result by SingleR.\"\n";
#$nfigure++;
}

### Interaction ###
if($step=~/6/){
    foreach my $each(@samples){
        # system("mkdir -p $BGI_result/$each/06.Interaction");
        system ("mkdir -m 755 -p $BGI_result/$each/06.Interaction") unless (-d "$BGI_result/$each/06.Interaction");
#system("cp $indir/$each/06.Interaction/*.png $indir/$each/06.Interaction/*.pdf $BGI_result/$each/06.Interaction");
        system("cp $indir/$each/06.Interaction/cellchat*.png $indir/$each/06.Interaction/cellchat*.pdf $BGI_result/$each/06.Interaction");
    }
    $tmp_nfig=$nfigure+1;
#    $arf_cn.="\n\@subtitle\nnumber = $subtitle\n细胞类群互作分析\n\@paragraph\nCellPhoneDB\\reference{10}是一个公开的受体-配体相互作用的数据库，整合了现有的细胞通讯数据集和手动校正的信息，其数据来源于UniProt，Ensembl，PDB，IMEx联盟，IUPHAR等。本项目使用CellPhoneDB来鉴定时空数据中的配体/受体关系和细胞间的通讯分子，研究不同细胞类型之间的相互交流及通讯网络。所有细胞类群间的通讯网络见图$nfigure，每个类群与其他类群间的通讯网络见图$tmp_nfig。\n";
#    $nreference++
    $arf_cn.="\n\@subtitle\nnumber = $subtitle\n细胞类群互作分析\n\@paragraph\nCellChat\\reference{$nreference}是一个能够从单细胞数据中定量推断和分析细胞间通信网络的工具，利用网络分析和模式识别方法预测细胞的主要信号输入和输出，以及这些细胞和信号如何协调功能。CellChatDB数据库整合了来自KEGG和最近研究中的信号分析信息，该数据库囊括了已知的配体-受体复合物组成，包括配体-受体多聚体复合物以及几类辅酶因子。本项目使用CellChat来鉴定时空数据中的配体/受体关系和细胞间的通讯分子，研究不同细胞类型之间的相互交流及通讯网络。所有细胞类群间的通讯网络见图$nfigure，每个类群与其他类群间的通讯网络见图$tmp_nfig。\n";
    $arf_en.="\n\@subtitle\nnumber = $subtitle\nInteraction of Cell Clusters\n\@paragraph\nCellChat\\reference{$nreference} is a tool capable of quantitatively inferring and analyzing cell-to-cell communication networks from single-cell data, using network analysis and pattern recognition methods to predict the main signal inputs and outputs of cells and how these cells and signals coordinate their functions. The CellChatDB database incorporates signal analysis information from KEGG and recent studies. The database includes known ligand-receptor complex compositions, including ligand-receptor polymeric complexes and several coenzyme factors. In this project, CellChat was used to identify ligand/receptor relationships and intercellular communication molecules in spatio-temporal data, and to study the interaction and communication networks between different cell types.The communication network among all cell clusters is shown in Fig$nfigure, and the communication network between each cluster and other clusters is shown in Fig$tmp_nfig.\n";
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"所有细胞类群间的细胞通讯网络图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Communication network diagram between all cell clusters\"\n";
    foreach my $each(@samples){
#$arf_cn.="file =  <url = BGI_result/$each/06.Interaction/network.png; label = \"${each}\">\n";
        $arf_cn.="file =  <url = BGI_result/$each/06.Interaction/cellchat_network.png; label = \"${each}\">\n";
        $arf_en.="file =  <url = BGI_result/$each/06.Interaction/cellchat_network.png; label = \"${each}\">\n";
    }
    $arf_cn.="size = <width = 800>\ndesc=\"连线越粗表示两个cluster之间的互作越强。\"\n";
    $arf_en.="size = <width = 800>\ndesc=\"The thicker the connection line, the stronger the interaction between two clusters\"\n";
    $nfigure++;

    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"每个细胞类群与其他类群间的细胞通讯网络图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Communication network diagram between each cell cluster and others\"\n";
    foreach my $each(@samples){
#$arf_cn.="file =  <url = BGI_result/$each/06.Interaction/seperate.png; label = \"${each}\">\n";
        $arf_cn.="file =  <url = BGI_result/$each/06.Interaction/cellchat_seperate.png; label = \"${each}\">\n";
        $arf_en.="file =  <url = BGI_result/$each/06.Interaction/cellchat_seperate.png; label = \"${each}\">\n";
    }
    $arf_cn.="size = <width = 800>\ndesc=\"连线越粗表示两个cluster之间的互作越强。\"\n";
    $arf_en.="size = <width = 800>\ndesc=\"The thicker the connection line, the stronger the interaction between two clusters\"\n";
    $nfigure++;
    $nreference++;
}

### GO KEGG ###
my $tmp_nref1=$nreference+1;
my $tmp_nref2=$nreference+2;
if($step=~/7/){
    foreach my $each(@samples){
        # system("mkdir -p $BGI_result/$each/07.GO_KEGG");
        system ("mkdir -m 755 -p $BGI_result/$each/07.GO_KEGG") unless (-d "$BGI_result/$each/07.GO_KEGG");
        system("cp $indir/$each/07.GO_KEGG/*.list $indir/$each/07.GO_KEGG/*.png $indir/$each/07.GO_KEGG/*.pdf $BGI_result/$each/07.GO_KEGG");
    }
    $tmp_nfig=$nfigure+3;
    $arf_cn.="\n\@subtitle\nnumber = $subtitle\n功能富集分析\n\@paragraph\n在每一种细胞类群的所有Marker基因中筛选显著的差异表达基因（P-value < 0.05 && Log2FC > 0.5），使用clusterProfiler软件分别对每一个细胞类群的差异基因进行GO（Gene Ontology）和KEGG（Kyoto Encyclopedia of Genes and Genomes）功能富集分析\\reference{$nreference}\\reference{$tmp_nref1}\\reference{$tmp_nref2}。GO和KEGG富集分析结果图和网络连接图见图$nfigure到$tmp_nfig。\n";
    $arf_en.="\n\@subtitle\nnumber = $subtitle\n Functional Enrichment Analysis\n\@paragraph\nSignificat differently expressed Genes(DEGs, P-value < 0.05 && Log2FC > 0.5) were screened from all Marker genes in each cell cluster. ClusterProfiler was used to conduct functional enrichment analysis of GO (Gene Ontology) and KEGG (Kyoto Encyclopedia of Genes and Genomes) categories\\reference{10}\\reference{11}\\reference{12}. Enrichment results and network connection diagrams are shown from Figure $nfigure to $tmp_nfig.\n";
    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"GO富集分析结果图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Heatmap of GO enrichment\"\n";
    foreach my $each(@samples){
        my @gofiles=`ls $BGI_result/$each/07.GO_KEGG/cluster*.GO.dotplot.png | sort -k1.8n | awk -F"cluster" '{print \$2}'| awk -F"." '{print \$1}'`;
        chomp @gofiles;
        foreach my $gg(@gofiles){
            my $tmp_label=
                $arf_cn.="file =  <url = BGI_result/$each/07.GO_KEGG/cluster$gg.degs.list.GO.dotplot.png; label = \"${each}_${gg} cluster\">\n";
            $arf_en.="file =  <url = BGI_result/$each/07.GO_KEGG/cluster$gg.degs.list.GO.dotplot.png; label = \"${each}_${gg} cluster\">\n";
        }
    }
    $arf_cn.="size = <width = 1200>\ndesc=\"横轴为富集基因占比，纵轴为富集到的GO term，颜色对应P-value的值，越红表示富集效果越显著。\"\n";
    $arf_en.="size = <width = 1200>\ndesc=\"X-axis, ratio of enriched genes; y-axis, the enriched GO term; The dot color corresponds to log10(P-value), and the redder the color, the more significant the enrichment.\"\n";
    $nfigure++;
    $nreference=$tmp_nref2;

    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"KEGG富集分析结果图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Heatmap of KEGG enrichment analysis\"\n";
    foreach my $each(@samples){
        my @keggfiles=`ls $BGI_result/$each/07.GO_KEGG/cluster*.KEGG.dotplot.png | sort -k1.8n |awk -F"cluster" '{print \$2}'|awk -F"." '{print \$1}'`;
        chomp @keggfiles;
        foreach my $kk(@keggfiles){
            $arf_cn.="file =  <url = BGI_result/$each/07.GO_KEGG/cluster$kk.degs.list.KEGG.dotplot.png; label = \"${each}_${kk} cluster\">\n";
            $arf_en.="file =  <url = BGI_result/$each/07.GO_KEGG/cluster$kk.degs.list.KEGG.dotplot.png; label = \"${each}_${kk} cluster\">\n";
        }
    }
    $arf_cn.="size = <width = 1200>\ndesc=\"横轴为富集基因占比，纵轴为富集到的KEGG Pathway，颜色对应P-value的值，越红表示富集效果越显著。\"\n";
    $arf_en.="size = <width = 1200>\ndesc=\"X-axis, ratio of enriched genes; y-axis, enriched KEGG Pathway; The dot color corresponds to log10(P-value), and the redder the color, the more significant the enrichment.\"\n";
    $nfigure++;

    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"GO富集分析网络连接图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Network connection diagram of GO enrichment analysis\"\n";
    foreach my $each(@samples){
        my @gofiles=`ls $BGI_result/$each/07.GO_KEGG/cluster*.GO.emapplot.png | sort -k1.8n | awk -F"cluster" '{print \$2}'| awk -F"." '{print \$1}'`;
        chomp @gofiles;
        foreach my $gg(@gofiles){
            $arf_cn.="file =  <url = BGI_result/$each/07.GO_KEGG/cluster$gg.degs.list.GO.emapplot.png; label = \"${each}_${gg} cluster\">\n";
            $arf_en.="file =  <url = BGI_result/$each/07.GO_KEGG/cluster$gg.degs.list.GO.emapplot.png; label = \"${each}_${gg} cluster\">\n";
        }
    }
    $arf_cn.="size = <width = 600>\ndesc=\"圆点为富集到的GO term，圆点大小表示基因数，圆点颜色表示P-value的值，越红表示富集效果越显著；连接线的粗细表示两个GO terms之间共有的基因数。\"\n";
    $arf_en.="size = <width = 600>\ndesc=\"The dot is the enriched GO term, the dot size represents the number of genes, the dot color corresponds to the P-value, and the redder the color, the more significant the enrichment. The thickness of the connection line indicates the number of common genes between two GO terms.\"\n";
    $nfigure++;

    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"KEGG富集分析网络连接图\"\n";
    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Network connection diagram of KEGG enrichment analysis\"\n";
    foreach my $each(@samples){
        my @keggfiles=`ls $BGI_result/$each/07.GO_KEGG/cluster*.KEGG.emapplot.png | sort -k1.8n |awk -F"cluster" '{print \$2}'|awk -F"." '{print \$1}'`;
        chomp @keggfiles;
        foreach my $kk(@keggfiles){
            $arf_cn.="file =  <url = BGI_result/$each/07.GO_KEGG/cluster$kk.degs.list.KEGG.emapplot.png; label = \"${each}_${kk} cluster\">\n";
            $arf_en.="file =  <url = BGI_result/$each/07.GO_KEGG/cluster$kk.degs.list.KEGG.emapplot.png; label = \"${each}_${kk} cluster\">\n";
        }
    }
    $arf_cn.="size = <width = 600>\ndesc=\"圆点为富集到的KEGG Pathway，圆点大小表示基因数，圆点颜色表示P-value的值，越红表示富集效果越显著；连接线的粗细表示两个GO terms之间共有的基因数。\"\n";
    $arf_en.="size = <width = 600>\ndesc=\"The dot is the enriched KEGG Pathway, the dot size represents the number of genes, the dot color corresponds to the P-value, and the redder the color, the more significant the enrichment. The thickness of the connection line indicates the number of common genes between two GO terms.\"\n";
    $nfigure++;

#    $tmp_nfig=$nfigure+1;
#    $arf_cn.="\n\@paragraph\n筛选在多于一半的细胞类群中都有的显著差异表达的基因，统计这些基因在每个细胞类群中的富集显著程度，制作热图，结果见图$nfigure和$tmp_nfig。\n";
#    $arf_en.="\n\@paragraph\nDEGs that are common in more than half of all clusters were screened, the enrichment significance of these genes in each cell cluster was counted, and the heatmap were shown in Figure $nfigure and $tmp_nfig.\n";
#    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"共有差异表达基因的GO富集结果热图\"\n";
#    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Heatmap of GO enrichment\"\n";
#    foreach my $each(@samples){
#        $arf_cn.="file =  <url = BGI_result/$each/07.GO_KEGG/GO.paste.out.clusters_pheatmap.png; label = \"${each}\">\n";
#        $arf_en.="file =  <url = BGI_result/$each/07.GO_KEGG/GO.paste.out.clusters_pheatmap.png; label = \"${each}\">\n";
#    }
#    $arf_cn.="size = <width = 900>\ndesc=\"每行为一个富集到的GO term，每列为一个cluster，颜色对应P-value的值，越红表示富集效果越显著。\"\n";
#    $arf_en.="size = <width = 900>\ndesc=\"Each row represents an enriched GO terms, and each column represents a cluster of cluster analysis results. The block color corresponds to -log10(P-value) and and the redder the color, the more significant the enrichment.\"\n";
#
#    $nfigure++;
#    $arf_cn.="\@figure\nnumber = $nfigure\ntitle = \"共有差异表达基因的KEGG富集结果热图\"\n";
#    $arf_en.="\@figure\nnumber = $nfigure\ntitle = \"Heatmap of KEGG enrichment\"\n";
#    foreach my $each(@samples){
#        $arf_cn.="file =  <url = BGI_result/$each/07.GO_KEGG/KEGG.paste.out.clusters_pheatmap.png; label = \"${each}\">\n";
#        $arf_en.="file =  <url = BGI_result/$each/07.GO_KEGG/KEGG.paste.out.clusters_pheatmap.png; label = \"${each}\">\n";
#    }
#    $arf_cn.="size = <width = 600>\ndesc=\"每行为一个富集到的KEGG Pathway，每列为一个cluster，颜色对应P-value的值，越红表示富集效果越显著。\"\n";
#    $arf_en.="size = <width = 900>\ndesc=\"Each row represents an enriched KEGG Pathway, and each column represents a cluster of cluster analysis results. The block color corresponds to -log10(P-value) and and the redder the color, the more significant the enrichment.\"\n";
#    $nfigure++;
}

open ARF_CN,">$outdir/HTML_report/arf/results_cn.arf";
open ARF_EN,">$outdir/HTML_report/arf/results_en.arf";
print ARF_CN "$arf_cn\n";
print ARF_EN "$arf_en\n";
close ARF_CN;
close ARF_EN;

system ("cp /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/STOmics/arf_demo/* $outdir/HTML_report/arf");
system ("cp /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/STOmics/resource_demo/* $outdir/HTML_report/resource");
system ("cp /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/STOmics/report.txt $outdir/HTML_report/report.txt.temp");
system ("cp $pinfo $outdir/HTML_report/report.txt.temp");
system ("cp /ldfssz1/ST_OCEAN/USER/liaoshangfeng/Pipline/HTML_arf/bin/arf2html.STOmics.sh $outdir/HTML_report");

sub usage{
    print STDERR"\e[;35;3m
        ---------------   Version    --------------
        Author:   Rui Zhang
        Email:    zhangrui7\@genomics.cn
        Update:   2021.11
        -------------   Description   -------------
        An auto-html report pipeline for STOmics analysis, containg:
        01.Filter, 02.GeneExpMatrix, 03.Cluster, 04.Pseudotime,
        05.Annotation, 06.Interaction, 07.GO_KEGG

        \e[;33;3m    -------------   Parameters    -------------
       *-sample             all sample IDs, split by space or comma;
       *-bin                bin size, same with analysis;
        -step               default 1234567, 01-07 all reported;
        -indir	            the directory that contains all samples, default `pwd`;
        -outdir             the output directory, default `pwd`/HTML_report;
        -help               print usage informartion;
        ---------------   Example   ---------------
        perl $0 -sample sample1,sample2,sample3 -bin 50  \n\n \e[;32;3m
        perl $0 -sample sample1,sample2,sample3 -bin 50 -step 12346 \n\n \e[;32;3m";
    return;
}
