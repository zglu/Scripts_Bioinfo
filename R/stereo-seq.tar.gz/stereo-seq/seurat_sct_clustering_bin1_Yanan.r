# from Yanan Xing
# usage: Rscript seurat_sct_clustering_bin1.r [matrix_file] [bin_size] [sample name] [orig.ident] 
# eg. Rscript ../seurat_sct_clustering_bin1.r E9.5_E2S4_GEM_bin1.tsv 100 mouse E9
library(dplyr)
library(Matrix)
library(data.table)
library(Seurat)
library(ggplot2)
library(ggsci)
library(RColorBrewer)
library(cowplot)

args<-commandArgs(T)
cols<-unique(c(pal_npg("nrc")(10),pal_aaas("default")(10),pal_nejm("default")(8),pal_lancet("lanonc")(9),
			pal_jama("default")(7),pal_jco("default")(10),pal_ucscgb("default")(26),pal_d3("category10")(10),
			pal_locuszoom("default")(7),pal_igv("default")(51),
			pal_uchicago("default")(9),pal_startrek("uniform")(7),
			pal_tron("legacy")(7),pal_futurama("planetexpress")(12),
			pal_rickandmorty("schwifty")(12),
			pal_simpsons("springfield")(16),
			pal_gsea("default")(12)))

binsize <- args[2]
binsize <- as.numeric(binsize)
read_mat<-function(mat){
  data<-fread(mat,header=T)
  data$x = floor(data$x/binsize)
  data$y = floor(data$y/binsize)
  data$cellID<-paste(data$x,data$y,sep="_")
  gene=unique(data$geneID)
  cell=unique(data$cellID)
  gene_idx=c(1:length(gene))
  cell_idx=c(1:length(cell))
  names(gene_idx)=gene
  names(cell_idx)=cell
  mat=sparseMatrix(i=gene_idx[data$geneID],j=cell_idx[data$cellID],x=data$MIDCounts)
  rownames(mat)=gene
  colnames(mat)=cell
  return(mat)
}


load_obj <- function(mat){
  SeuObj<-CreateSeuratObject(counts = mat)
  SeuObj[["percent.mt"]] <- PercentageFeatureSet(SeuObj, pattern = "^mt-|^MT-|^Mt-")
 # SeuObj <- NormalizeData(SeuObj, normalization.method = "RC")

  SeuObj@meta.data$coor_x=sub(rownames(SeuObj@meta.data),pattern = "_.*",replacement = "")
  SeuObj@meta.data$coor_y=sub(rownames(SeuObj@meta.data),pattern = ".*_",replacement = "")
  SeuObj@meta.data$coor_x=sub(SeuObj@meta.data$coor_x,pattern = "X",replacement = "")
  SeuObj@meta.data$coor_x=as.integer(SeuObj@meta.data$coor_x)
  SeuObj@meta.data$coor_y=as.integer(SeuObj@meta.data$coor_y)
 
  SeuObj
}

mat <- read_mat(args[1])
seuobj <- load_obj(mat)



seuobj %>%  NormalizeData()%>%
  FindVariableFeatures()%>%
  ScaleData(features = rownames(seuobj))  %>%
  SCTransform(verbose = FALSE) %>%
  RunPCA(verbose = FALSE,assay="SCT") %>%
  RunUMAP( dims = 1:30, verbose = FALSE)%>%
  FindNeighbors( dims = 1:30, verbose = FALSE)%>%
  FindClusters(verbose = FALSE) -> seuobj

DefaultAssay(seuobj) <- "RNA"
deg <- FindAllMarkers(seuobj,only.pos = TRUE)
write.csv(deg,paste0("./", "/" ,args[3],"_deg",".csv"))
deg.2 <- deg %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)

#saveRDS(seuobj,paste0("./", "/" ,args[3],"_seuobj",".rds"))

pdf(paste0("./", "/" ,args[3], ".pdf"),width=20,height=10)
p1= ggplot(seuobj@meta.data,aes(as.numeric(coor_x), as.numeric(coor_y), fill= seurat_clusters))+ 
  geom_tile()+
  theme_classic()+
  coord_fixed()+ 
  scale_fill_manual(values =cols)+
  labs(fill="clusters")


median <- median(seuobj@meta.data$nCount_RNA)
seuobj@meta.data$title <- "number of transcripts"
seuobj@meta.data$orig.ident <- args[4]
p2 <- ggplot(seuobj@meta.data,aes(orig.ident,nCount_RNA))+
    geom_violin() + 
    labs(y="number of transcripts",x=NULL) +
    theme(panel.grid.major=element_line(colour=NA))+
    theme_bw()+facet_grid(. ~ title)+
    theme(strip.text.x = element_text(size = 30))+   
    theme(axis.title.x = element_text(size = 20),axis.title.y = element_text(size = 20),plot.title = element_text(hjust = 1,vjust=-40,size=14) )+
    theme(axis.text.x = element_text(size = 20,color="black"),axis.text.y = element_text(size = 20,color="black")) +
    geom_boxplot(width=0.2)+ annotate("text",label=as.character(median),y=as.numeric(median),x=1.1,hjust = 0,color='red',size=10)


median <- median(seuobj@meta.data$nFeature_RNA)
seuobj@meta.data$title <- "number of genes"
seuobj@meta.data$orig.ident <- args[4]
p3 <- ggplot(seuobj@meta.data,aes(orig.ident,nFeature_RNA))+
    geom_violin() + 
    labs(y="number of genes",x=NULL) +
    theme(panel.grid.major=element_line(colour=NA))+
    theme_bw()+facet_grid(. ~ title)+
    theme(strip.text.x = element_text(size = 30))+   
    theme(axis.title.x = element_text(size = 20),axis.title.y = element_text(size = 20),plot.title = element_text(hjust = 1,vjust=-40,size=14) )+
    theme(axis.text.x = element_text(size = 20,color="black"),axis.text.y = element_text(size = 20,color="black")) +
    geom_boxplot(width=0.2)+ annotate("text",label=as.character(median),y=as.numeric(median),x=1.1,hjust = 0,color='red',size=10)

p4 <- DoHeatmap(seuobj,features = deg.2$gene)
p5 <- ggplot(seuobj@meta.data, aes(x=nFeature_RNA)) + 
      geom_density()+labs(title = "distribution of genes")+ 
      theme_classic()+
      theme(axis.title.x = element_text(size = 20),axis.title.y = element_text(size = 20) )+    
      theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 30))

p6 <- ggplot(seuobj@meta.data, aes(x=nCount_RNA)) + 
      geom_density()+labs(title = "distribution of transcripts")+
      theme_classic()+
      theme(axis.title.x = element_text(size = 20),axis.title.y = element_text(size = 20) )+    
      theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 30))


p7 <- ggplot(seuobj@meta.data,aes(as.numeric(coor_x), as.numeric(coor_y), fill= nFeature_RNA))+
  geom_tile()+
  theme_classic()+
  coord_fixed()+
  scale_fill_gradient(low = "palegoldenrod", high = "magenta4")+
  labs(fill="gene counts",x=NULL,y=NULL,title = "distribution of genes")+
  theme(axis.title.x = element_text(size = 20),axis.title.y = element_text(size = 20) )+ 
  theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 30))

p8 <- ggplot(seuobj@meta.data,aes(as.numeric(coor_x), as.numeric(coor_y), fill= nCount_RNA))+
    geom_tile()+
    theme_classic()+
    coord_fixed()+
    scale_fill_gradient(low = "palegoldenrod", high = "magenta4")+
    labs(fill="transcript counts",x=NULL,y=NULL,title = "distribution of transcripts")+
    theme(axis.title.x = element_text(size = 20),axis.title.y = element_text(size = 20) )+    
    theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 30))


p.list1 <- list(p2,p3)
p.list2 <- list(p5,p6)
p.list3 <- list(p7,p8)
p.list4 <- list(p1,p4)

print(plot_grid(plotlist = p.list1,ncol = 2))
print(plot_grid(plotlist = p.list2,ncol = 2))
print(plot_grid(plotlist = p.list3,ncol = 2))
print(plot_grid(plotlist = p.list4,ncol = 2))


dev.off()


summary(seuobj@meta.data$nFeature_RNA)
summary(seuobj@meta.data$nCount_RNA)
dim(seuobj@assays$RNA@counts)

saveRDS(seuobj,paste0("./", "/" ,args[3],"_seuobj",".rds"))
