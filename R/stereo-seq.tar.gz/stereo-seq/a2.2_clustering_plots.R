# Rscript a2.2_plots-after-sct.R [rds after sctransform]
# output: two pdf files (_CLUSTERS.pdf + _FEATURES.pdf)

library(Seurat)
library(dplyr)
library(ggplot2)
library(ggsci)
library(gridExtra)

args<-commandArgs(T)

myCol<-unique(c(pal_d3("category10")(10),pal_rickandmorty("schwifty")(12), pal_lancet("lanonc")(9),
      pal_npg("nrc")(10),pal_aaas("default")(10),pal_nejm("default")(8),
			pal_jama("default")(7),pal_jco("default")(10),
			pal_locuszoom("default")(7),pal_startrek("uniform")(7),
			pal_tron("legacy")(7),pal_futurama("planetexpress")(12),
			pal_simpsons("springfield")(16),
			pal_gsea("default")(12)))

SeuObj<-readRDS(args[1])

# write files for SpatialDE, HotSpot, SCENIC, etc


# change parameters
#SeuObj <- RunUMAP(SeuObj, dims = 1:20, verbose = F)
#SeuObj <- FindNeighbors(SeuObj, dims = 1:20, verbose = FALSE)
#SeuObj <- FindClusters(SeuObj, verbose = FALSE, res=0.75, graph.name = "SCT_snn")

DefaultAssay(SeuObj) <- "RNA"
#deg <- FindAllMarkers(SeuObj,only.pos = TRUE, test.use="roc") # method; pval
deg<-read.csv(paste0(args[1],"_allMarkers_roc",".csv"))
deg.top <- deg %>% group_by(cluster) %>% top_n(n = 1, wt = avg_log2FC)
deg.topmarkers<-as.vector(deg.top$gene)


message("Number of cells per cluster:")
table(SeuObj@active.ident)

## plotting 
pdf(paste0(args[1], "_CLUSTERS.pdf"),width=10,height=5)

# spatial feature plot
p1<-ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= nFeature_RNA))+
  geom_tile()+
  theme_void()+
  coord_fixed()+
  scale_fill_gradient(low = "#fcf5eb", high = "#800080")+
  labs(fill="gene counts",x=NULL,y=NULL,title = "nFeature_RNA")+
  theme(axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15) )+ 
  theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 15))

p2<-ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= nCount_RNA))+
  geom_tile()+
  theme_void()+
  coord_fixed()+
  scale_fill_gradient(low = "#fcf5eb", high = "#800080")+
  labs(fill="read counts",x=NULL,y=NULL,title = "nCount_RNA")+
  theme(axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15) )+ 
  theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 15))


p3 <- ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= seurat_clusters))+ 
  geom_tile()+
  theme_void()+
  coord_fixed()+ 
  scale_fill_manual(values =myCol)+
  labs(fill="clusters")

p4 <- DimPlot(SeuObj, reduction = "umap", cols=myCol, label = TRUE) + NoLegend() + coord_fixed()

#p3 <- DoHeatmap(SeuObj,features = deg.top$gene)

p6<-DotPlot(SeuObj, features = deg.topmarkers) + RotatedAxis()

p7<-FeatureScatter(SeuObj, group.by = "ident",feature1 = "nCount_RNA", feature2 = "nFeature_RNA", cols=myCol)
p8<-FeatureScatter(SeuObj, group.by = "ident",feature1 = "nFeature_RNA", feature2 = "percent.mt", cols=myCol)

grid.arrange(p7,p8,ncol = 2)
grid.arrange(p1,p2,ncol = 2)
grid.arrange(p4,p3,ncol = 2)
grid.arrange(p6,ncol = 1)
dev.off()
message("Cluster plots exported.")


##### top marker plot
p <- lapply(deg.topmarkers, function(x) {
tmexp<-as.matrix(SeuObj@assays$SCT@counts[x,])  
ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= tmexp[,1]))+ 
  geom_tile()+
  theme_void()+
  coord_fixed()+ 
  scale_fill_gradient(low = "#fcf5eb", high = "#800080")+
  labs(title=x, fill="Counts")
})

ggsave(
   filename = paste0(args[1],"_FEATURES.pdf"), 
   plot = marrangeGrob(p, nrow=3, ncol=3), 
   width = 15, height = 9
)

message("Feature spatial plots exported.")
