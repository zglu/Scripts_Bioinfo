#!/bin/bash

# find the path for T1 flowcells
# ./findT7.sh [FC]

for i in R1100600190009 R1100600210004 R1100600210007 R1100600210008; do echo "/storeDataElite/ztron/autorunDW/DNBSEQ-T7/${i}/write_fastq_config_1/ztron/";  ls -l /storeDataElite/ztron/autorunDW/DNBSEQ-T7/${i}/write_fastq_config_1/ztron/ | grep $1; done
