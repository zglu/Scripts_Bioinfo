#!/bin/bash

for i in 100 150 200; do
    cp scatter_50x50_MID_gene_counts.png scatter_${i}x${i}_MID_gene_counts.png
    cp statistic_50x50_MID_gene_DNB.png statistic_${i}x${i}_MID_gene_DNB.png
    cp violin_50x50_MID_gene.png violin_${i}x${i}_MID_gene.png
done
