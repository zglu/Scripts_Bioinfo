docker run --rm -v /mgi_storage/sk/luzhigang1/analysis/seurat/:/home satijalab/seurat /usr/local/bin/Rscript /home/test.R hello
