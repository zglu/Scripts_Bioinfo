#!/bin/bash

if [[ $# -lt 2 ]] ; then
    echo './cp_G400.sh [RXXX dir] [FC id'
    echo 'eg. ./cp_G400.sh R2130400190012 V300109651'
    exit 1
fi

for i in {1..4}; do
mkdir L0${i}
cp /storeDataElite/ztron/rawdata/$1/$2/L0${i}/$2_L0${i}_read_1.fq.gz L0${i}/
cp /storeDataElite/ztron/rawdata/$1/$2/L0${i}/$2_L0${i}_read_2.fq.gz L0${i}/
done
