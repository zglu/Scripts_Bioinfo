#!/bin/bash

inDIR=/mgi_storage/sk/luzhigang1/scripts
outDIR=EXAMPLE-OUT
SN=EXAMPLE-SN
BINSIZE=20
NCLUSTER=5
RSif=/mgi_storage/sk/stomics/r_scSpatial_tools.sif
GioSif=/mgi_storage/sk/stomics/r_Giotto1.1.2_sp.sif

export SINGULARITY_BIND=$inDIR,$outDIR

singularity exec ${RSif} Rscript \
    ${inDIR}/a0_bin2rds-SCT.R ${outDIR}/analysis/${SN}.raw ${BINSIZE} bin${BINSIZE}

singularity exec ${RSif} Rscript \
    ${inDIR}/a0_bin2rds-SCT.R ${outDIR}/analysis/${SN}.tissue.gem ${BINSIZE} bin${BINSIZE}

#singularity exec ${RSif} Rscript \
#    ${inDIR}/BayesSpace.R ${outDIR}/analysis/${SN}.tissue.gem_BIN${BINSIZE}_SCT.rds ${NCLUSTER} 
#
#singularity exec ${GioSif} Rscript \
#    ${inDIR}/Giotto.R ${outDIR}/analysis/${SN}.tissue.gem_BIN${BINSIZE}_SCT.rds


#cellbin
#singularity exec ${RSif} Rscript \
#    ${inDIR}/b0_cellbin2rds_sct.R ${outDIR}/analysis/${SN}.cellbin.gem cellbin

# check feaures if provided
#for i in `cat markers.ids`; do
#  echo $i
#  singularity exec ${RSif} Rscript ${inDIR}/featureSpatial_raw.R ${SN}.raw.gem_BIN${BINSIZE}.rds $i bin50
#  singularity exec ${RSif} Rscript ${inDIR}/featureSpatial_sct.R ${SN}.tissue.gem_BIN${BINSIZE}_SCT.rds $i bin50
#done

