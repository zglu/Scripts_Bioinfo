library(Seurat)
library(ggplot2)
library(gridExtra)

args<-commandArgs(T)

SeuObj<-readRDS(args[1])
SeuObj<-FindClusters(SeuObj, res=c(0.6, 0.8, 1.0, 1.2))

p0.6 <- ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= integrated_snn_res.0.6))+
  geom_tile()+ theme_void()+ coord_fixed()+ labs(fill="Seurat res0.6")

p0.8 <- ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= integrated_snn_res.0.8))+
  geom_tile()+ theme_void()+ coord_fixed()+ labs(fill="Seurat res0.8")

p1.0 <- ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= integrated_snn_res.1))+
  geom_tile()+ theme_void()+ coord_fixed()+ labs(fill="Seurat res1.0")

p1.2 <- ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= integrated_snn_res.1.2))+
  geom_tile()+ theme_void()+ coord_fixed()+ labs(fill="Seurat res1.2")

pdf("integrated_dimplot_diffRes.pdf", width=12, height=6)
#grid.arrange(p0.6,p0.8,ncol = 2)
grid.arrange(p0.6)
grid.arrange(p0.8)
grid.arrange(p1.0)
grid.arrange(p1.2)
dev.off()

