# Rscript a2_clustering_after_sct.R [rds file] [resolution]
# output: SCtransformed RDS + cluster plot + feature spatial plot

args<-commandArgs(T)


library(Seurat)
library(ggplot2)
#library(ggsci)
library(dplyr)
library(RColorBrewer)
library(gridExtra)

SeuObj<-readRDS(args[1])
myRes<-as.numeric(args[2])

head(SeuObj@meta.data)


#display.brewer.all()
myCol<-unique(c(brewer.pal(8, "Dark2"), brewer.pal(12, "Paired"), brewer.pal(12, "Set3"),
     brewer.pal(8, "Set1"), brewer.pal(8, "Accent")))

message("Summary of nFeature")
summary(SeuObj@meta.data$nFeature_RNA)

message("Summary of nCount")
summary(SeuObj@meta.data$nCount_RNA)

p1.2<-ggplot(SeuObj@meta.data,aes(x=nCount_RNA, y=nFeature_RNA, color=percent.mt)) +
  	geom_point() +
	scale_colour_gradient(low = "gray90", high = "black") +
  	theme_classic()

# complexity
SeuObj$log10GenesPerUMI <- log10(SeuObj$nFeature_RNA) / log10(SeuObj$nCount_RNA)
p2<-ggplot(SeuObj@meta.data, aes(x=log10GenesPerUMI)) +
  	geom_density(alpha = 0.4, fill="khaki1") + labs(title = "log10 Genes per UMI")+
  	theme_classic() #+
  	#geom_vline(xintercept = 0.8)

#p3<-FeatureScatter(SeuObj, feature1 = "nFeature_RNA", feature2 = "percent.mt")
p3.2<-ggplot(SeuObj@meta.data,aes(x=nFeature_RNA, y=percent.mt, color=nCount_RNA)) +
  	geom_point() +
	scale_colour_gradient(low = "gray90", high = "black") +
  	theme_classic()

#p4<-VlnPlot(SeuObj, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), pt.size = 0.1)

median <- median(SeuObj@meta.data$nCount_RNA)
p5 <- ggplot(SeuObj@meta.data,aes(orig.ident,nCount_RNA))+
    geom_violin() +
    labs(y="nUMI",x=NULL) +
    theme(panel.grid.major=element_line(colour=NA))+
    theme_bw()+
    theme(strip.text.x = element_text(size = 15))+
    theme(axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15),plot.title = element_text(hjust = 1,vjust=-40,size=14) )+
    theme(axis.text.x = element_text(size = 15,color="black"),axis.text.y = element_text(size = 15,color="black")) +
    geom_boxplot(width=0.2)+ annotate("text",label=as.character(median),y=as.numeric(median),x=1.1,hjust = 0,color='red',size=5)

median <- median(SeuObj@meta.data$nFeature_RNA)
p6 <- ggplot(SeuObj@meta.data,aes(orig.ident,nFeature_RNA))+
    geom_violin() +
    labs(y="nGene",x=NULL) +
    theme(panel.grid.major=element_line(colour=NA))+
    theme_bw()+
    theme(strip.text.x = element_text(size = 15))+
    theme(axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15),plot.title = element_text(hjust = 1,vjust=-40,size=14) )+
    theme(axis.text.x = element_text(size = 15,color="black"),axis.text.y = element_text(size = 15,color="black")) +
    geom_boxplot(width=0.2)+ annotate("text",label=as.character(median),y=as.numeric(median),x=1.1,hjust = 0,color='red',size=5)


p7 <- ggplot(SeuObj@meta.data, aes(x=nFeature_RNA)) +
      geom_density(alpha = 0.4, fill="lightblue")+labs(title = "distribution of nGene")+
      theme_classic()#+
      #theme(axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15) )+
      #theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 15))

p8 <- ggplot(SeuObj@meta.data, aes(x=nCount_RNA)) +
      geom_density(alpha = 0.4, fill="bisque")+labs(title = "distribution of nUMI")+
      theme_classic()#+
      #theme(axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15) )+
      #theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 15))


p9 <- ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= nFeature_RNA))+
  geom_tile()+
  theme_void()+
  coord_fixed()+
  scale_fill_gradient(low = "palegoldenrod", high = "magenta4")+
  labs(fill="nGene",x=NULL,y=NULL,title = NULL)+
  theme(axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15) )+
  theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 15))

p10 <- ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= nCount_RNA))+
    geom_tile()+
    theme_void()+
    coord_fixed()+
    scale_fill_gradient(low = "palegoldenrod", high = "magenta4")+
    labs(fill="nUMI",x=NULL,y=NULL,title = NULL)+
    theme(axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15) )+
    theme(plot.title = element_text(hjust =0.5,vjust = 0.5,size = 15))

# change parameters 
#SeuObj <- RunUMAP(SeuObj, dims = 1:20, verbose = F)
#SeuObj <- FindNeighbors(SeuObj, dims = 1:20, verbose = FALSE)
#SeuObj <- FindClusters(SeuObj, verbose = FALSE, res=0.75, graph.name = "SCT_snn"

SeuObj <- FindClusters(SeuObj, resolution=myRes, verbose = FALSE)


message("Number of cells per cluster:")
table(SeuObj@active.ident)

DefaultAssay(SeuObj) <- "RNA"
#deg <- FindAllMarkers(SeuObj,only.pos = TRUE)#, min.pct = 0.25, logfc.threshold = 0.5) # method: wilcox
##deg<-subset(deg, deg$p_val<1e-20)
#write.csv(deg,paste0(args[1], "_BIN", binsize, ".rds_SCT.rds_allMarkers.csv"))
#
##deg_roc <- FindAllMarkers(SeuObj,only.pos = TRUE, test.use="roc") # method: roc
##write.csv(deg_roc,paste0(args[1],"_BIN", binsize, ".rds_SCT.rds_allMarkers_roc",".csv"))
#
#message("Marker genes exported.")

#deg.top <- deg %>% group_by(cluster) %>% top_n(n = 3, wt = avg_log2FC)
#deg.topmarkers<-as.vector(deg.top$gene)

## plotting
pdf(paste0(args[1], "_QC-CLUSTERS.pdf"),width=10,height=5)


pp3 <- ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= seurat_clusters))+
  geom_tile()+
  theme_void()+
  coord_fixed()+
  scale_fill_manual(values = myCol)+
  labs(fill="Seurat clusters")

pp4 <- DimPlot(SeuObj, reduction = "umap", cols=myCol, label = TRUE) + NoLegend() + coord_fixed()

pp7<-FeatureScatter(SeuObj, group.by = "ident",feature1 = "nCount_RNA", feature2 = "nFeature_RNA", cols=myCol)
pp8<-FeatureScatter(SeuObj, group.by = "ident",feature1 = "nFeature_RNA", feature2 = "percent.mt", cols=myCol)
pp9<-VlnPlot(SeuObj, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), pt.size = 0.1)

grid.arrange(p9,p10,ncol = 2 ,top=paste0("Spatial distribution of nGene and nUMI"))
grid.arrange(p6,p5,ncol = 2, top="nGene and nUMI per cell (bin unit)")
grid.arrange(p7,p8,p2,ncol = 3)
#print(p4)
grid.arrange(p1.2,p3.2,ncol = 2, top="Scatter plot of each cell (bin unit)")

grid.arrange(pp4,pp3,ncol = 2, top="Seurat clustering")
#print(pp5)
#print(pp9)
grid.arrange(pp7,pp8,ncol = 2, top="Scatter plot grouped by clusters")
dev.off()

message("QC and Cluster plots exported.")

##### top markers plots
#p <- lapply(deg.topmarkers, function(x) {
#tmexp<-as.matrix(SeuObj@assays$SCT@data[x,]) #@counts - unnormalised counts; @data normlised data (log or sct)
#ggplot(SeuObj@meta.data,aes(as.numeric(coord_x), as.numeric(coord_y), fill= tmexp[,1]))+
#  geom_tile()+
#  theme_void()+
#  coord_fixed()+
#  scale_fill_gradient(low = "#fcf5eb", high = "#800080")+
#  labs(title=x, fill="") # sct-normalised data
#})
#
#ggsave(
#   filename = paste0(args[1],"_BIN", binsize,".rds_SCT.rds_FEATURES.pdf"),
#   plot = marrangeGrob(p, nrow=3, ncol=3),
#   width = 10, height = 5
#)
#
#message("Feature spatial plots exported.")


